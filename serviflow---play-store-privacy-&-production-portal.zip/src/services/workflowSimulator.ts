import { ServiceRequest, ServiceWorkflowStatus, UserProfile, UserRole } from '../types';

export interface SecurityTestResult {
  id: string;
  name: string;
  category: string;
  attackVector: string;
  expectedBehavior: string;
  actualOutcome: string;
  status: 'PASSED' | 'FAILED';
  httpStatus: number;
  securityMessage: string;
}

export const SAMPLE_CUSTOMERS: UserProfile[] = [
  {
    id: 'cust_001',
    name: 'Sarah Jenkins',
    email: 'sarah.jenkins@example.com',
    role: 'CUSTOMER',
    phone: '+1 (555) 234-5678',
    verified: true,
    totalJobs: 14,
  },
  {
    id: 'cust_002',
    name: 'Marcus Vance',
    email: 'marcus.vance@example.com',
    role: 'CUSTOMER',
    phone: '+1 (555) 876-5432',
    verified: true,
    totalJobs: 3,
  },
];

export const SAMPLE_PROFESSIONALS: UserProfile[] = [
  {
    id: 'pro_901',
    name: 'David Miller (Master Plumber)',
    email: 'david.miller@proflow.com',
    role: 'PROFESSIONAL',
    phone: '+1 (555) 432-1098',
    verified: true,
    rating: 4.96,
    totalJobs: 248,
  },
  {
    id: 'pro_902',
    name: 'Elena Rostova (Certified Electrician)',
    email: 'elena.rostova@electritech.com',
    role: 'PROFESSIONAL',
    phone: '+1 (555) 654-3210',
    verified: true,
    rating: 4.92,
    totalJobs: 189,
  },
];

// Initial seeded requests matching the exact workflow
export const INITIAL_REQUESTS: ServiceRequest[] = [
  {
    id: 'REQ-84910',
    customerId: 'cust_001',
    customerName: 'Sarah Jenkins',
    customerPhone: '+1 (555) 234-5678',
    serviceCategory: 'Plumbing & Pipe Repair',
    serviceDescription: 'Kitchen main sink drain backing up and slow drain pipe leak under granite island.',
    address: '742 Evergreen Terrace, Springfield, OR',
    status: 'REQUEST_CREATED',
    createdAt: '2026-10-10 09:15 AM',
    updatedAt: '2026-10-10 09:15 AM',
    history: [
      {
        status: 'REQUEST_CREATED',
        timestamp: '2026-10-10 09:15 AM',
        actorRole: 'CUSTOMER',
        note: 'Customer posted new service request.',
      },
    ],
  },
  {
    id: 'REQ-72104',
    customerId: 'cust_001',
    customerName: 'Sarah Jenkins',
    customerPhone: '+1 (555) 234-5678',
    serviceCategory: 'HVAC Air Filter Replacement',
    serviceDescription: 'Quarterly seasonal filter replacement and intake duct inspection.',
    address: '742 Evergreen Terrace, Springfield, OR',
    status: 'JOB_COMPLETED',
    createdAt: '2026-10-08 02:00 PM',
    updatedAt: '2026-10-08 04:30 PM',
    professionalId: 'pro_901',
    professionalName: 'David Miller (Master Plumber)',
    amount: 120,
    scheduledDate: '2026-10-08',
    scheduledTime: '03:00 PM',
    history: [
      { status: 'REQUEST_CREATED', timestamp: '2026-10-08 02:00 PM', actorRole: 'CUSTOMER', note: 'Created' },
      { status: 'PROFESSIONAL_ACCEPTED', timestamp: '2026-10-08 02:15 PM', actorRole: 'PROFESSIONAL', note: 'Proposal: $120' },
      { status: 'CUSTOMER_CONFIRMED', timestamp: '2026-10-08 02:20 PM', actorRole: 'CUSTOMER', note: 'Confirmed' },
      { status: 'PROFESSIONAL_ARRIVED', timestamp: '2026-10-08 02:55 PM', actorRole: 'PROFESSIONAL', note: 'Arrived on site' },
      { status: 'JOB_STARTED', timestamp: '2026-10-08 03:00 PM', actorRole: 'PROFESSIONAL', note: 'Job in progress' },
      { status: 'JOB_COMPLETED', timestamp: '2026-10-08 04:30 PM', actorRole: 'CUSTOMER', note: 'Customer accepted completion' },
    ],
  },
];

export class WorkflowEngine {
  private requests: ServiceRequest[] = [...INITIAL_REQUESTS];
  private listeners: Array<() => void> = [];

  public getRequests(): ServiceRequest[] {
    return [...this.requests];
  }

  public getRequestById(id: string): ServiceRequest | undefined {
    return this.requests.find((r) => r.id === id);
  }

  public subscribe(callback: () => void): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter((cb) => cb !== callback);
    };
  }

  private notify() {
    this.listeners.forEach((cb) => cb());
  }

  // 1. Create request (Customer only)
  public createRequest(params: {
    customerId: string;
    customerName: string;
    customerPhone: string;
    serviceCategory: string;
    serviceDescription: string;
    address: string;
  }): { success: boolean; request?: ServiceRequest; error?: string } {
    const newReq: ServiceRequest = {
      id: `REQ-${Math.floor(10000 + Math.random() * 90000)}`,
      customerId: params.customerId,
      customerName: params.customerName,
      customerPhone: params.customerPhone,
      serviceCategory: params.serviceCategory,
      serviceDescription: params.serviceDescription,
      address: params.address,
      status: 'REQUEST_CREATED',
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      updatedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      history: [
        {
          status: 'REQUEST_CREATED',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          actorRole: 'CUSTOMER',
          note: 'Customer posted service request.',
        },
      ],
    };

    this.requests = [newReq, ...this.requests];
    this.notify();
    return { success: true, request: newReq };
  }

  // 2. Step 2: Professional Accepts and sets Amount, Date, Time
  public professionalAccept(params: {
    requestId: string;
    professionalId: string;
    professionalName: string;
    amount: number;
    scheduledDate: string;
    scheduledTime: string;
  }): { success: boolean; error?: string } {
    const req = this.requests.find((r) => r.id === params.requestId);
    if (!req) return { success: false, error: 'Request not found' };

    // STRICT WORKFLOW CHECK: Can only accept if status is REQUEST_CREATED
    if (req.status !== 'REQUEST_CREATED') {
      return {
        success: false,
        error: `Illegal state transition. Cannot accept request in state '${req.status}'. Must be 'REQUEST_CREATED'.`,
      };
    }

    // Input validation: Amount must be numeric and positive
    if (typeof params.amount !== 'number' || isNaN(params.amount) || params.amount <= 0) {
      return { success: false, error: 'Amount must be a positive numeric value.' };
    }

    if (!params.scheduledDate || !params.scheduledTime) {
      return { success: false, error: 'Scheduled Date and Time are strictly required.' };
    }

    req.status = 'PROFESSIONAL_ACCEPTED';
    req.professionalId = params.professionalId;
    req.professionalName = params.professionalName;
    req.amount = params.amount;
    req.scheduledDate = params.scheduledDate;
    req.scheduledTime = params.scheduledTime;
    req.updatedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    req.history.push({
      status: 'PROFESSIONAL_ACCEPTED',
      timestamp: req.updatedAt,
      actorRole: 'PROFESSIONAL',
      note: `Professional proposed $${params.amount} on ${params.scheduledDate} at ${params.scheduledTime}.`,
    });

    this.notify();
    return { success: true };
  }

  // 3. Step 3: Customer Confirms OR Rejects
  public customerRespondProposal(params: {
    requestId: string;
    customerId: string;
    action: 'ACCEPT' | 'REJECT';
    tamperedAmount?: number; // Used in security attack testing
  }): { success: boolean; error?: string } {
    const req = this.requests.find((r) => r.id === params.requestId);
    if (!req) return { success: false, error: 'Request not found' };

    // IDOR check: Customer must be the owner of the request
    if (req.customerId !== params.customerId) {
      return {
        success: false,
        error: 'Forbidden (403): You cannot respond to requests belonging to another customer.',
      };
    }

    // State machine check: Must be in PROFESSIONAL_ACCEPTED
    if (req.status !== 'PROFESSIONAL_ACCEPTED') {
      return {
        success: false,
        error: `Illegal state transition. Cannot confirm request in state '${req.status}'. Must be 'PROFESSIONAL_ACCEPTED'.`,
      };
    }

    // Security check: Customer CANNOT modify proposal amount
    if (params.tamperedAmount !== undefined && params.tamperedAmount !== req.amount) {
      return {
        success: false,
        error: 'Tampering Detected (400): Customer cannot alter the price set by Professional.',
      };
    }

    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    if (params.action === 'ACCEPT') {
      req.status = 'CUSTOMER_CONFIRMED';
      req.updatedAt = timeStr;
      req.history.push({
        status: 'CUSTOMER_CONFIRMED',
        timestamp: timeStr,
        actorRole: 'CUSTOMER',
        note: `Customer accepted proposal of $${req.amount}. Booking confirmed.`,
      });
    } else {
      req.status = 'CANCELLED';
      req.updatedAt = timeStr;
      req.history.push({
        status: 'CANCELLED',
        timestamp: timeStr,
        actorRole: 'CUSTOMER',
        note: 'Customer rejected professional proposal. Request cancelled.',
      });
    }

    this.notify();
    return { success: true };
  }

  // 4. Step 4: Professional Arrived
  public professionalMarkArrived(params: {
    requestId: string;
    professionalId: string;
  }): { success: boolean; error?: string } {
    const req = this.requests.find((r) => r.id === params.requestId);
    if (!req) return { success: false, error: 'Request not found' };

    if (req.professionalId !== params.professionalId) {
      return { success: false, error: 'Forbidden (403): You are not assigned to this job.' };
    }

    if (req.status !== 'CUSTOMER_CONFIRMED') {
      return {
        success: false,
        error: `Illegal state transition. Cannot mark arrived from '${req.status}'. Must be 'CUSTOMER_CONFIRMED'.`,
      };
    }

    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    req.status = 'PROFESSIONAL_ARRIVED';
    req.updatedAt = timeStr;
    req.history.push({
      status: 'PROFESSIONAL_ARRIVED',
      timestamp: timeStr,
      actorRole: 'PROFESSIONAL',
      note: 'Professional arrived at customer location.',
    });

    this.notify();
    return { success: true };
  }

  // 5. Step 5: Professional Starts Job
  public professionalStartJob(params: {
    requestId: string;
    professionalId: string;
  }): { success: boolean; error?: string } {
    const req = this.requests.find((r) => r.id === params.requestId);
    if (!req) return { success: false, error: 'Request not found' };

    if (req.professionalId !== params.professionalId) {
      return { success: false, error: 'Forbidden (403): You are not assigned to this job.' };
    }

    if (req.status !== 'PROFESSIONAL_ARRIVED') {
      return {
        success: false,
        error: `Illegal state transition. Cannot start job from '${req.status}'. Must be 'PROFESSIONAL_ARRIVED'.`,
      };
    }

    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    req.status = 'JOB_STARTED';
    req.updatedAt = timeStr;
    req.history.push({
      status: 'JOB_STARTED',
      timestamp: timeStr,
      actorRole: 'PROFESSIONAL',
      note: 'Job commenced by professional.',
    });

    this.notify();
    return { success: true };
  }

  // 6. Step 6: Customer Completes Job
  public customerCompleteJob(params: {
    requestId: string;
    customerId: string;
  }): { success: boolean; error?: string } {
    const req = this.requests.find((r) => r.id === params.requestId);
    if (!req) return { success: false, error: 'Request not found' };

    // STRICT ROLE SECURITY: ONLY Customer can complete the job!
    if (req.customerId !== params.customerId) {
      return {
        success: false,
        error: 'Forbidden (403): Only the verified Customer can mark the job as completed.',
      };
    }

    if (req.status !== 'JOB_STARTED') {
      return {
        success: false,
        error: `Illegal state transition. Cannot complete job from '${req.status}'. Must be 'JOB_STARTED'.`,
      };
    }

    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    req.status = 'JOB_COMPLETED';
    req.updatedAt = timeStr;
    req.history.push({
      status: 'JOB_COMPLETED',
      timestamp: timeStr,
      actorRole: 'CUSTOMER',
      note: 'Customer inspected and accepted completion of service.',
    });

    this.notify();
    return { success: true };
  }

  // Calculation of counts for a professional (Section 11)
  public getCountsForProfessional(professionalId: string): {
    active: number;
    completed: number;
    cancelled: number;
  } {
    const proRequests = this.requests.filter((r) => r.professionalId === professionalId);

    const active = proRequests.filter(
      (r) =>
        r.status === 'CUSTOMER_CONFIRMED' ||
        r.status === 'PROFESSIONAL_ARRIVED' ||
        r.status === 'JOB_STARTED'
    ).length;

    const completed = proRequests.filter((r) => r.status === 'JOB_COMPLETED').length;
    const cancelled = proRequests.filter((r) => r.status === 'CANCELLED').length;

    return { active, completed, cancelled };
  }

  public resetToSample() {
    this.requests = JSON.parse(JSON.stringify(INITIAL_REQUESTS));
    this.notify();
  }
}

export const workflowInstance = new WorkflowEngine();
