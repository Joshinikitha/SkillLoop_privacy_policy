import React, { useState } from 'react';
import { Header } from './components/Header';
import { PrivacyPolicyViewer } from './components/PrivacyPolicyViewer';
import { AccountDeletionSection } from './components/AccountDeletionSection';
import { DataSafetySection } from './components/DataSafetySection';
import { AppSimulator } from './components/AppSimulator';
import { SecurityAuditSuite } from './components/SecurityAuditSuite';
import { AuditReportView } from './components/AuditReportView';
import { AccountDeletionModal } from './components/AccountDeletionModal';
import { Footer } from './components/Footer';
import { ShieldCheck, ArrowRight, ExternalLink, FileText, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<
    'privacy' | 'datasafety' | 'deletion' | 'simulator' | 'security' | 'audit'
  >('privacy');

  const [isDeletionModalOpen, setIsDeletionModalOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-neutral-50 text-neutral-900 selection:bg-neutral-900 selection:text-white">
      {/* Top Bar Contract */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenDeletionModal={() => setIsDeletionModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {activeTab === 'privacy' && (
          <PrivacyPolicyViewer
            onNavigateToDeletion={() => setActiveTab('deletion')}
            onNavigateToDataSafety={() => setActiveTab('datasafety')}
          />
        )}

        {activeTab === 'datasafety' && <DataSafetySection />}

        {activeTab === 'deletion' && <AccountDeletionSection />}

        {activeTab === 'simulator' && <AppSimulator />}

        {activeTab === 'security' && <SecurityAuditSuite />}

        {activeTab === 'audit' && <AuditReportView />}
      </main>

      {/* Footer */}
      <Footer onSelectTab={(tab) => setActiveTab(tab)} />

      {/* Global Account Deletion Modal */}
      <AccountDeletionModal
        isOpen={isDeletionModalOpen}
        onClose={() => setIsDeletionModalOpen(false)}
      />
    </div>
  );
}
