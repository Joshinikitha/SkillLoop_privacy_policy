import React, { useState, useEffect } from 'react';
import {
  workflowInstance,
  SAMPLE_CUSTOMERS,
  SAMPLE_PROFESSIONALS,
} from '../services/workflowSimulator';
import { ServiceRequest, ServiceWorkflowStatus, UserRole } from '../types';
import {
  Smartphone,
  CheckCircle2,
  XCircle,
  MapPin,
  Clock,
  DollarSign,
  Calendar,
  AlertCircle,
  RefreshCw,
  ArrowRight,
  ShieldCheck,
  Send,
  User,
  Wrench,
  Navigation,
} from 'lucide-react';

export const AppSimulator: React.FC = () => {
  const [requests, setRequests] = useState<ServiceRequest[]>(workflowInstance.getRequests());
  const [activeView, setActiveView] = useState<'SPLIT' | 'CUSTOMER' | 'PRO'>('SPLIT');

  // Active accounts
  const [currentCustomer, setCurrentCustomer] = useState(SAMPLE_CUSTOMERS[0]);
  const [currentPro, setCurrentPro] = useState(SAMPLE_PROFESSIONALS[0]);

  // Form states for Step 1 (Create request)
  const [category, setCategory] = useState('Plumbing & Pipe Repair');
  const [description, setDescription] = useState('Water pressure low in master bath and faucet leak.');
  const [address, setAddress] = useState('742 Evergreen Terrace, Springfield, OR');

  // Form states for Step 2 (Professional Proposal)
  const [proposalAmount, setProposalAmount] = useState<number>(145);
  const [proposalDate, setProposalDate] = useState('2026-10-12');
  const [proposalTime, setProposalTime] = useState('10:30 AM');
  const [activeProposalReqId, setActiveProposalReqId] = useState<string | null>(null);

  // Status feedback / alerts
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Subscribe to real-time updates from workflow engine
  useEffect(() => {
    const unsubscribe = workflowInstance.subscribe(() => {
      setRequests(workflowInstance.getRequests());
    });
    return unsubscribe;
  }, []);

  const counts = workflowInstance.getCountsForProfessional(currentPro.id);

  // 1. Create Request (Customer)
  const handleCreateRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim() || !address.trim()) return;

    const res = workflowInstance.createRequest({
      customerId: currentCustomer.id,
      customerName: currentCustomer.name,
      customerPhone: currentCustomer.phone,
      serviceCategory: category,
      serviceDescription: description,
      address,
    });

    if (res.success) {
      setFeedback({ type: 'success', message: 'Step 1: Request Created! Visible in Professional queue.' });
      setDescription('');
    }
  };

  // 2. Submit Proposal (Professional)
  const handleSendProposal = (requestId: string) => {
    const res = workflowInstance.professionalAccept({
      requestId,
      professionalId: currentPro.id,
      professionalName: currentPro.name,
      amount: Number(proposalAmount),
      scheduledDate: proposalDate,
      scheduledTime: proposalTime,
    });

    if (res.success) {
      setFeedback({
        type: 'success',
        message: `Step 2: Professional Proposal submitted ($${proposalAmount}, ${proposalDate} ${proposalTime})! Customer must confirm.`,
      });
      setActiveProposalReqId(null);
    } else {
      setFeedback({ type: 'error', message: res.error || 'Failed to submit proposal' });
    }
  };

  // 3. Confirm Proposal (Customer)
  const handleCustomerConfirm = (requestId: string, action: 'ACCEPT' | 'REJECT') => {
    const res = workflowInstance.customerRespondProposal({
      requestId,
      customerId: currentCustomer.id,
      action,
    });

    if (res.success) {
      if (action === 'ACCEPT') {
        setFeedback({
          type: 'success',
          message: 'Step 3: Customer Confirmed booking! Booking is now Active in Professional dashboard.',
        });
      } else {
        setFeedback({
          type: 'success',
          message: 'Proposal Rejected by Customer. Status marked CANCELLED. Cancelled count increased.',
        });
      }
    } else {
      setFeedback({ type: 'error', message: res.error || 'Action failed' });
    }
  };

  // 4. Mark Arrived (Professional)
  const handleProfessionalArrive = (requestId: string) => {
    const res = workflowInstance.professionalMarkArrived({
      requestId,
      professionalId: currentPro.id,
    });

    if (res.success) {
      setFeedback({
        type: 'success',
        message: 'Step 4: Professional Arrived! Customer live tracking updated to "Vendor Arrived on Site".',
      });
    } else {
      setFeedback({ type: 'error', message: res.error || 'Arrival update failed' });
    }
  };

  // 5. Start Job (Professional)
  const handleProfessionalStartJob = (requestId: string) => {
    const res = workflowInstance.professionalStartJob({
      requestId,
      professionalId: currentPro.id,
    });

    if (res.success) {
      setFeedback({
        type: 'success',
        message: 'Step 5: Job Started! Timer running. Customer notified that work is in progress.',
      });
    } else {
      setFeedback({ type: 'error', message: res.error || 'Job start failed' });
    }
  };

  // 6. Complete Job (Customer Only)
  const handleCustomerComplete = (requestId: string) => {
    const res = workflowInstance.customerCompleteJob({
      requestId,
      customerId: currentCustomer.id,
    });

    if (res.success) {
      setFeedback({
        type: 'success',
        message: 'Step 6: Customer Job Completed! Verified by customer. Professional completed count updated.',
      });
    } else {
      setFeedback({ type: 'error', message: res.error || 'Completion failed' });
    }
  };

  // Filter requests for views
  const customerRequests = requests.filter((r) => r.customerId === currentCustomer.id);
  const proAvailableRequests = requests.filter(
    (r) => r.status === 'REQUEST_CREATED' || r.professionalId === currentPro.id
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Top Banner & Canonical Workflow Indicator */}
      <div className="border-b border-neutral-200 pb-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-neutral-500 mb-1">
              <span>Section 2 & 9 Verification</span>
              <span aria-hidden="true">·</span>
              <span>Canonical 6-Step Workflow</span>
              <span aria-hidden="true">·</span>
              <span>Zero-Refresh Real-Time Sync</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-neutral-900">
              Live Workflow Simulator: Customer App + Professional App
            </h1>
          </div>

          {/* View switcher */}
          <div className="flex items-center gap-1 p-1 bg-neutral-100 rounded-lg shrink-0">
            <button
              onClick={() => setActiveView('SPLIT')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeView === 'SPLIT'
                  ? 'bg-white text-neutral-900 shadow-2xs font-semibold'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Side-by-Side Dual View
            </button>
            <button
              onClick={() => setActiveView('CUSTOMER')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeView === 'CUSTOMER'
                  ? 'bg-white text-neutral-900 shadow-2xs font-semibold'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Customer App View
            </button>
            <button
              onClick={() => setActiveView('PRO')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeView === 'PRO'
                  ? 'bg-white text-neutral-900 shadow-2xs font-semibold'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Professional App View
            </button>
          </div>
        </div>

        {/* 6-step roadmap indicator */}
        <div className="mt-5 bg-neutral-100/80 p-3.5 rounded-xl border border-neutral-200 text-xs">
          <div className="text-[11px] font-semibold text-neutral-700 uppercase tracking-wider mb-2">
            The Canonical 6-Step Lifecycle (Audited Sequence)
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-center text-[11px]">
            <div className="bg-white p-2 rounded-lg border border-neutral-200/80 font-medium text-neutral-800">
              <span className="font-mono text-neutral-400 block text-[10px]">Step 1</span>
              REQUEST_CREATED
            </div>
            <div className="bg-white p-2 rounded-lg border border-neutral-200/80 font-medium text-neutral-800">
              <span className="font-mono text-neutral-400 block text-[10px]">Step 2</span>
              PRO_ACCEPTED
              <span className="text-[9px] text-neutral-500 block">Amount/Date/Time</span>
            </div>
            <div className="bg-white p-2 rounded-lg border border-neutral-200/80 font-medium text-neutral-800">
              <span className="font-mono text-neutral-400 block text-[10px]">Step 3</span>
              CUSTOMER_CONFIRMED
              <span className="text-[9px] text-neutral-500 block">Or CANCELLED</span>
            </div>
            <div className="bg-white p-2 rounded-lg border border-neutral-200/80 font-medium text-neutral-800">
              <span className="font-mono text-neutral-400 block text-[10px]">Step 4</span>
              PRO_ARRIVED
              <span className="text-[9px] text-neutral-500 block">Live Tracker Alert</span>
            </div>
            <div className="bg-white p-2 rounded-lg border border-neutral-200/80 font-medium text-neutral-800">
              <span className="font-mono text-neutral-400 block text-[10px]">Step 5</span>
              JOB_STARTED
              <span className="text-[9px] text-neutral-500 block">Work In Progress</span>
            </div>
            <div className="bg-white p-2 rounded-lg border border-neutral-200/80 font-medium text-neutral-800">
              <span className="font-mono text-neutral-400 block text-[10px]">Step 6</span>
              JOB_COMPLETED
              <span className="text-[9px] text-neutral-500 block">By Customer Only</span>
            </div>
          </div>
        </div>

        {/* Global Feedback notification */}
        {feedback && (
          <div
            className={`mt-4 p-3 rounded-xl border text-xs flex items-center justify-between transition-all ${
              feedback.type === 'success'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-red-50 border-red-200 text-red-900'
            }`}
          >
            <div className="flex items-center gap-2">
              {feedback.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              )}
              <span>{feedback.message}</span>
            </div>
            <button
              onClick={() => setFeedback(null)}
              className="text-neutral-500 hover:text-neutral-900 text-xs px-2"
            >
              Dismiss
            </button>
          </div>
        )}
      </div>

      {/* Simulator Workspace Grid */}
      <div className={`grid gap-6 ${activeView === 'SPLIT' ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'}`}>
        {/* ============================================================ */}
        {/* LEFT COLUMN: CUSTOMER APP VIEW */}
        {/* ============================================================ */}
        {(activeView === 'SPLIT' || activeView === 'CUSTOMER') && (
          <div className="bg-white rounded-2xl border border-neutral-200 shadow-2xs overflow-hidden flex flex-col">
            {/* Customer Header Bar */}
            <div className="bg-neutral-900 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
                  C
                </div>
                <div>
                  <div className="text-xs font-bold flex items-center gap-1.5">
                    <span>SkillLoop Customer</span>
                    <span className="text-[10px] bg-neutral-800 px-1.5 py-0.2 rounded text-neutral-300">Active</span>
                  </div>
                  <div className="text-[11px] text-neutral-400">
                    Logged in as: {currentCustomer.name} ({currentCustomer.email})
                  </div>
                </div>
              </div>

              {/* Account switcher */}
              <select
                value={currentCustomer.id}
                onChange={(e) => {
                  const c = SAMPLE_CUSTOMERS.find((x) => x.id === e.target.value);
                  if (c) setCurrentCustomer(c);
                }}
                className="text-[11px] bg-neutral-800 text-neutral-200 border border-neutral-700 rounded-md px-2 py-1"
              >
                {SAMPLE_CUSTOMERS.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Customer Body */}
            <div className="p-5 space-y-6 flex-1 bg-neutral-50/30">
              {/* Step 1: Create Request Form */}
              <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-2xs">
                <div className="flex items-center gap-1.5 text-xs font-bold text-neutral-900 mb-2">
                  <Send className="w-3.5 h-3.5 text-neutral-700" />
                  <span>Step 1: Create Service Request</span>
                </div>

                <form onSubmit={handleCreateRequest} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-[11px] font-medium text-neutral-600 mb-1">
                      Service Category
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-neutral-50 border border-neutral-200 rounded-lg text-neutral-800"
                    >
                      <option value="Plumbing & Pipe Repair">Plumbing & Pipe Repair</option>
                      <option value="HVAC Air Conditioning Service">HVAC Air Conditioning Service</option>
                      <option value="Electrical Panel Inspection">Electrical Panel Inspection</option>
                      <option value="Smart Lock & Security Installation">Smart Lock & Security Installation</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-neutral-600 mb-1">
                      Job Description
                    </label>
                    <input
                      type="text"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="Describe the issue..."
                      className="w-full px-2.5 py-1.5 bg-neutral-50 border border-neutral-200 rounded-lg text-neutral-800"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-neutral-600 mb-1">
                      Service Address
                    </label>
                    <input
                      type="text"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-neutral-50 border border-neutral-200 rounded-lg text-neutral-800"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2 bg-neutral-900 text-white rounded-lg font-medium text-xs hover:bg-neutral-800 transition-colors cursor-pointer"
                  >
                    Post Request (Status: REQUEST_CREATED)
                  </button>
                </form>
              </div>

              {/* Customer Active Bookings / Timeline */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
                    My Requests & Active Bookings ({customerRequests.length})
                  </h3>
                </div>

                {customerRequests.length === 0 ? (
                  <div className="p-6 bg-white rounded-xl border border-neutral-200 text-center text-xs text-neutral-500">
                    No active requests. Post a service request above to test the workflow.
                  </div>
                ) : (
                  customerRequests.map((req) => (
                    <div
                      key={req.id}
                      className="bg-white p-4 rounded-xl border border-neutral-200 shadow-2xs space-y-3 text-xs"
                    >
                      {/* Top status header */}
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="font-bold text-neutral-900">{req.serviceCategory}</div>
                          <div className="text-[11px] text-neutral-500 font-mono">ID: {req.id}</div>
                        </div>

                        {/* Status label without pills */}
                        <div className="text-right">
                          <div className="font-mono text-[11px] font-semibold text-neutral-900">
                            {req.status}
                          </div>
                          <div className="text-[10px] text-neutral-400">{req.updatedAt}</div>
                        </div>
                      </div>

                      <p className="text-neutral-700 text-xs bg-neutral-50 p-2.5 rounded-lg border border-neutral-100">
                        "{req.serviceDescription}"
                      </p>

                      <div className="text-[11px] text-neutral-500 flex items-center gap-1.5">
                        <MapPin className="w-3 h-3 text-neutral-400 shrink-0" />
                        <span className="truncate">{req.address}</span>
                      </div>

                      {/* WORKFLOW STEP 3 ACTIONS: Customer accepts or rejects proposal */}
                      {req.status === 'PROFESSIONAL_ACCEPTED' && (
                        <div className="bg-amber-50/70 p-3 rounded-xl border border-amber-200/80 space-y-2">
                          <div className="font-semibold text-amber-950 text-xs flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5 text-amber-600" />
                            <span>Step 3: Proposal Received from {req.professionalName}</span>
                          </div>

                          <div className="grid grid-cols-3 gap-2 bg-white/90 p-2 rounded-lg border border-amber-200/60 text-center text-[11px]">
                            <div>
                              <div className="text-[10px] text-neutral-500">Proposed Price</div>
                              <div className="font-bold text-neutral-900 font-mono">${req.amount}</div>
                            </div>
                            <div>
                              <div className="text-[10px] text-neutral-500">Date</div>
                              <div className="font-medium text-neutral-800">{req.scheduledDate}</div>
                            </div>
                            <div>
                              <div className="text-[10px] text-neutral-500">Time</div>
                              <div className="font-medium text-neutral-800">{req.scheduledTime}</div>
                            </div>
                          </div>

                          <div className="flex gap-2 pt-1">
                            <button
                              onClick={() => handleCustomerConfirm(req.id, 'ACCEPT')}
                              className="flex-1 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-medium text-xs transition-colors flex items-center justify-center gap-1"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Accept Proposal (Confirm)</span>
                            </button>
                            <button
                              onClick={() => handleCustomerConfirm(req.id, 'REJECT')}
                              className="px-3 py-1.5 bg-red-100 hover:bg-red-200 text-red-800 rounded-lg font-medium text-xs transition-colors flex items-center justify-center gap-1"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              <span>Reject (Cancel)</span>
                            </button>
                          </div>
                        </div>
                      )}

                      {/* LIVE TRACKER: Visible when professional is on the way / arrived / started */}
                      {(req.status === 'CUSTOMER_CONFIRMED' ||
                        req.status === 'PROFESSIONAL_ARRIVED' ||
                        req.status === 'JOB_STARTED') && (
                        <div className="bg-blue-50/80 p-3 rounded-xl border border-blue-200/80 space-y-2">
                          <div className="flex items-center justify-between text-xs font-semibold text-blue-950">
                            <div className="flex items-center gap-1.5">
                              <Navigation className="w-3.5 h-3.5 text-blue-600" />
                              <span>Live Job Tracker</span>
                            </div>
                            <span className="font-mono text-[10px] text-blue-700 uppercase">
                              {req.status === 'CUSTOMER_CONFIRMED' && 'En Route to Location'}
                              {req.status === 'PROFESSIONAL_ARRIVED' && 'Vendor Arrived on Site'}
                              {req.status === 'JOB_STARTED' && 'Work In Progress'}
                            </span>
                          </div>

                          <div className="text-[11px] text-blue-800 leading-relaxed">
                            {req.status === 'CUSTOMER_CONFIRMED' &&
                              `Professional ${req.professionalName} has accepted your confirmation and is in transit.`}
                            {req.status === 'PROFESSIONAL_ARRIVED' &&
                              `Professional is at your address (${req.address}). Ready for inspection.`}
                            {req.status === 'JOB_STARTED' &&
                              `Job currently being executed. Once completed to your satisfaction, click below.`}
                          </div>

                          {/* WORKFLOW STEP 6 ACTION: ONLY CUSTOMER MARKS JOB COMPLETED */}
                          {req.status === 'JOB_STARTED' && (
                            <div className="pt-2">
                              <button
                                onClick={() => handleCustomerComplete(req.id)}
                                className="w-full py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-medium text-xs transition-colors flex items-center justify-center gap-1.5 shadow-2xs"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>Step 6: Mark Job Completed (Customer Acceptance)</span>
                              </button>
                              <p className="text-[10px] text-neutral-500 text-center mt-1">
                                Strict Rule: Only Customer holds the authority to mark completion.
                              </p>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Completed / Cancelled state summaries */}
                      {req.status === 'JOB_COMPLETED' && (
                        <div className="bg-emerald-50 p-2.5 rounded-lg border border-emerald-200 text-emerald-900 text-[11px] flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span>Service successfully delivered and signed off. Invoiced: ${req.amount}.</span>
                        </div>
                      )}

                      {req.status === 'CANCELLED' && (
                        <div className="bg-neutral-100 p-2.5 rounded-lg border border-neutral-200 text-neutral-600 text-[11px] flex items-center gap-2">
                          <XCircle className="w-4 h-4 text-neutral-500 shrink-0" />
                          <span>Proposal rejected. Booking marked CANCELLED.</span>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* RIGHT COLUMN: PROFESSIONAL APP VIEW */}
        {/* ============================================================ */}
        {(activeView === 'SPLIT' || activeView === 'PRO') && (
          <div className="bg-white rounded-2xl border border-neutral-200 shadow-2xs overflow-hidden flex flex-col">
            {/* Pro Header Bar */}
            <div className="bg-neutral-900 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-xs">
                  P
                </div>
                <div>
                  <div className="text-xs font-bold flex items-center gap-1.5">
                    <span>SkillLoop Pro (Partner)</span>
                    <span className="text-[10px] bg-neutral-800 px-1.5 py-0.2 rounded text-neutral-300">Verified</span>
                  </div>
                  <div className="text-[11px] text-neutral-400">
                    Logged in as: {currentPro.name}
                  </div>
                </div>
              </div>

              {/* Account switcher */}
              <select
                value={currentPro.id}
                onChange={(e) => {
                  const p = SAMPLE_PROFESSIONALS.find((x) => x.id === e.target.value);
                  if (p) setCurrentPro(p);
                }}
                className="text-[11px] bg-neutral-800 text-neutral-200 border border-neutral-700 rounded-md px-2 py-1"
              >
                {SAMPLE_PROFESSIONALS.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Pro Body */}
            <div className="p-5 space-y-6 flex-1 bg-neutral-50/30">
              {/* SECTION 11 AUDIT: Reactive Dynamic Home Counts */}
              <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-2xs">
                <div className="text-[11px] font-semibold text-neutral-600 mb-2.5 flex items-center justify-between">
                  <span>Professional Home Dashboard Counts</span>
                  <span className="font-mono text-[10px] text-neutral-400">DB Computed (Section 11)</span>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-neutral-50 p-3 rounded-lg border border-neutral-200 text-center">
                    <div className="text-[10px] uppercase font-semibold text-neutral-500">Active</div>
                    <div className="text-2xl font-bold font-mono text-neutral-900 tabular-nums">
                      {counts.active}
                    </div>
                    <div className="text-[9px] text-neutral-400 truncate">CONFIRMED / ARRIVED / STARTED</div>
                  </div>

                  <div className="bg-neutral-50 p-3 rounded-lg border border-neutral-200 text-center">
                    <div className="text-[10px] uppercase font-semibold text-neutral-500">Completed</div>
                    <div className="text-2xl font-bold font-mono text-emerald-700 tabular-nums">
                      {counts.completed}
                    </div>
                    <div className="text-[9px] text-neutral-400 truncate">JOB_COMPLETED</div>
                  </div>

                  <div className="bg-neutral-50 p-3 rounded-lg border border-neutral-200 text-center">
                    <div className="text-[10px] uppercase font-semibold text-neutral-500">Cancelled</div>
                    <div className="text-2xl font-bold font-mono text-red-700 tabular-nums">
                      {counts.cancelled}
                    </div>
                    <div className="text-[9px] text-neutral-400 truncate">CANCELLED</div>
                  </div>
                </div>
              </div>

              {/* Pro Queue & Jobs */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
                    Assigned & Available Service Jobs ({proAvailableRequests.length})
                  </h3>
                </div>

                {proAvailableRequests.length === 0 ? (
                  <div className="p-6 bg-white rounded-xl border border-neutral-200 text-center text-xs text-neutral-500">
                    No requests currently in dispatch pool.
                  </div>
                ) : (
                  proAvailableRequests.map((req) => (
                    <div
                      key={req.id}
                      className="bg-white p-4 rounded-xl border border-neutral-200 shadow-2xs space-y-3 text-xs"
                    >
                      {/* Top status header */}
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="font-bold text-neutral-900">{req.serviceCategory}</div>
                          <div className="text-[11px] text-neutral-500 font-mono">Customer: {req.customerName}</div>
                        </div>

                        <div className="text-right">
                          <div className="font-mono text-[11px] font-semibold text-neutral-900">
                            {req.status}
                          </div>
                          <div className="text-[10px] text-neutral-400">{req.updatedAt}</div>
                        </div>
                      </div>

                      <p className="text-neutral-700 text-xs bg-neutral-50 p-2.5 rounded-lg border border-neutral-100">
                        "{req.serviceDescription}"
                      </p>

                      <div className="text-[11px] text-neutral-500 flex items-center gap-1.5">
                        <MapPin className="w-3 h-3 text-neutral-400 shrink-0" />
                        <span className="truncate">{req.address}</span>
                      </div>

                      {/* STEP 2 ACTION: Professional Sets Amount, Date, Time and Accepts */}
                      {req.status === 'REQUEST_CREATED' && (
                        <div className="bg-blue-50/70 p-3 rounded-xl border border-blue-200/80 space-y-3">
                          <div className="font-semibold text-blue-950 text-xs flex items-center justify-between">
                            <span>Step 2: Pro Accepts & Sets Proposal</span>
                            <span className="text-[10px] font-normal text-blue-700">Amount, Date, Time</span>
                          </div>

                          <div className="grid grid-cols-3 gap-2">
                            <div>
                              <label className="block text-[10px] font-medium text-neutral-600 mb-0.5">
                                Price ($)
                              </label>
                              <input
                                type="number"
                                min="1"
                                value={proposalAmount}
                                onChange={(e) => setProposalAmount(Number(e.target.value))}
                                className="w-full px-2 py-1 bg-white border border-neutral-300 rounded text-xs font-mono"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] font-medium text-neutral-600 mb-0.5">
                                Scheduled Date
                              </label>
                              <input
                                type="date"
                                value={proposalDate}
                                onChange={(e) => setProposalDate(e.target.value)}
                                className="w-full px-2 py-1 bg-white border border-neutral-300 rounded text-xs"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] font-medium text-neutral-600 mb-0.5">
                                Time
                              </label>
                              <input
                                type="text"
                                value={proposalTime}
                                onChange={(e) => setProposalTime(e.target.value)}
                                placeholder="10:00 AM"
                                className="w-full px-2 py-1 bg-white border border-neutral-300 rounded text-xs"
                              />
                            </div>
                          </div>

                          <button
                            onClick={() => handleSendProposal(req.id)}
                            className="w-full py-1.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg font-medium text-xs transition-colors flex items-center justify-center gap-1.5"
                          >
                            <DollarSign className="w-3.5 h-3.5" />
                            <span>Accept & Send Proposal to Customer</span>
                          </button>
                        </div>
                      )}

                      {/* STEP 4 ACTION: Vendor Arrived */}
                      {req.status === 'CUSTOMER_CONFIRMED' && (
                        <div className="bg-amber-50/70 p-3 rounded-xl border border-amber-200/80 space-y-2">
                          <div className="text-xs font-semibold text-amber-950">
                            Step 4: Customer Confirmed! En route to site.
                          </div>
                          <p className="text-[11px] text-amber-800">
                            Upon reaching customer premises, tap below to update live tracking.
                          </p>
                          <button
                            onClick={() => handleProfessionalArrive(req.id)}
                            className="w-full py-1.5 bg-amber-700 hover:bg-amber-800 text-white rounded-lg font-medium text-xs transition-colors flex items-center justify-center gap-1.5 shadow-2xs"
                          >
                            <MapPin className="w-3.5 h-3.5" />
                            <span>Once Vendor Arrived (Step 4: PROFESSIONAL_ARRIVED)</span>
                          </button>
                        </div>
                      )}

                      {/* STEP 5 ACTION: Job Started */}
                      {req.status === 'PROFESSIONAL_ARRIVED' && (
                        <div className="bg-blue-50/70 p-3 rounded-xl border border-blue-200/80 space-y-2">
                          <div className="text-xs font-semibold text-blue-950">
                            Step 5: On Site with Customer
                          </div>
                          <button
                            onClick={() => handleProfessionalStartJob(req.id)}
                            className="w-full py-1.5 bg-blue-700 hover:bg-blue-800 text-white rounded-lg font-medium text-xs transition-colors flex items-center justify-center gap-1.5 shadow-2xs"
                          >
                            <Wrench className="w-3.5 h-3.5" />
                            <span>Job Started (Step 5: JOB_STARTED)</span>
                          </button>
                        </div>
                      )}

                      {/* IN PROGRESS STATUS (Awaiting Customer completion) */}
                      {req.status === 'JOB_STARTED' && (
                        <div className="bg-neutral-100 p-3 rounded-xl border border-neutral-200 text-neutral-700 text-[11px] space-y-1">
                          <div className="font-semibold text-neutral-900 flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-neutral-600" />
                            <span>Work in Progress (Awaiting Customer Sign-off)</span>
                          </div>
                          <p className="text-neutral-500">
                            By security policy, only the customer can mark this job completed. The professional completed count will increment once the customer signs off.
                          </p>
                        </div>
                      )}

                      {req.status === 'JOB_COMPLETED' && (
                        <div className="bg-emerald-50 p-2.5 rounded-lg border border-emerald-200 text-emerald-900 text-[11px] flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span>Job Completed by Customer. Payout of ${req.amount} queued.</span>
                        </div>
                      )}

                      {req.status === 'CANCELLED' && (
                        <div className="bg-neutral-100 p-2.5 rounded-lg border border-neutral-200 text-neutral-600 text-[11px] flex items-center gap-2">
                          <XCircle className="w-4 h-4 text-neutral-500 shrink-0" />
                          <span>Request was cancelled by customer.</span>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
