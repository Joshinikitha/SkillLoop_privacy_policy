import React, { useState } from 'react';
import { PRIVACY_POLICY_METADATA, PRIVACY_POLICY_SECTIONS } from '../data/privacyPolicyData';
import { Search, Printer, Share2, CheckCircle2, ChevronRight, BookOpen, Shield, Mail } from 'lucide-react';

interface PrivacyPolicyViewerProps {
  onNavigateToDeletion: () => void;
  onNavigateToDataSafety: () => void;
}

export const PrivacyPolicyViewer: React.FC<PrivacyPolicyViewerProps> = ({
  onNavigateToDeletion,
  onNavigateToDataSafety,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [copied, setCopied] = useState(false);

  const filteredSections = PRIVACY_POLICY_SECTIONS.filter(
    (sec) =>
      sec.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sec.content.some((c) => c.toLowerCase().includes(searchQuery.toLowerCase())) ||
      sec.keyHighlights.some((h) => h.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Hero Header */}
      <div className="mb-10 pb-8 border-b border-neutral-200">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 text-xs text-neutral-500 mb-3">
              <span>Legal Document</span>
              <span aria-hidden="true">·</span>
              <span>Google Play Console Ready</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono text-neutral-700">v{PRIVACY_POLICY_METADATA.version}</span>
            </div>
            
            <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-neutral-950 mb-3" style={{ textWrap: 'balance' }}>
              Privacy Policy for Customer & Professional Apps
            </h1>

            <p className="text-base text-neutral-600 leading-relaxed">
              Official public privacy disclosure for <strong className="text-neutral-900 font-semibold">{PRIVACY_POLICY_METADATA.appNameCustomer}</strong> and <strong className="text-neutral-900 font-semibold">{PRIVACY_POLICY_METADATA.appNameProfessional}</strong>. Formulated for Google Play Developer Policies, GDPR, and CCPA/CPRA.
            </p>

            <div className="mt-4 flex flex-wrap items-center gap-y-2 gap-x-4 text-xs text-neutral-500">
              <span>Last Updated: <strong className="text-neutral-800 font-medium">{PRIVACY_POLICY_METADATA.lastUpdated}</strong></span>
              <span aria-hidden="true">·</span>
              <span>Effective Date: <strong className="text-neutral-800 font-medium">{PRIVACY_POLICY_METADATA.effectiveDate}</strong></span>
              <span aria-hidden="true">·</span>
              <span>Entity: <strong className="text-neutral-800 font-medium">{PRIVACY_POLICY_METADATA.organization}</strong></span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handlePrint}
              className="px-3 py-2 text-xs font-medium text-neutral-700 bg-white border border-neutral-200 rounded-lg hover:bg-neutral-50 transition-colors flex items-center gap-1.5 shadow-2xs"
              title="Print Privacy Policy"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / PDF</span>
            </button>

            <button
              onClick={handleShare}
              className="px-3 py-2 text-xs font-medium text-neutral-700 bg-white border border-neutral-200 rounded-lg hover:bg-neutral-50 transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer"
            >
              {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
              <span>{copied ? 'Link Copied!' : 'Copy Play Store URL'}</span>
            </button>
          </div>
        </div>

        {/* Visual Architectural Banner */}
        <div className="mt-8 relative rounded-2xl overflow-hidden border border-neutral-200/90 shadow-xs h-48 sm:h-64 bg-neutral-900">
          <img
            src="/src/assets/images/compliance_hero_banner_1791699532926.jpg"
            alt="SkillLoop Legal and Compliance Headquarters"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center brightness-90"
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/80 via-neutral-900/30 to-transparent flex items-end p-6">
            <div className="text-white max-w-xl">
              <div className="text-xs font-mono text-neutral-300 uppercase tracking-wider mb-1">
                Verified Compliance Gateway · SkillLoop Technologies, Inc.
              </div>
              <div className="text-base sm:text-lg font-bold tracking-tight">
                Global Service Privacy Policy & Play Store Regulatory Disclosures
              </div>
            </div>
          </div>
        </div>

        {/* Play Console Submission Direct Helper Banner */}
        <div className="mt-6 p-4 bg-neutral-900 text-neutral-100 rounded-xl border border-neutral-800 text-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="font-semibold text-white flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Google Play Console Ready · Production URL Endpoints</span>
            </div>
            <div className="text-neutral-400 text-[11px] flex flex-wrap items-center gap-x-4 gap-y-1">
              <span>Customer App ID: <code className="text-neutral-200 font-mono">com.skillloop.app</code></span>
              <span aria-hidden="true">·</span>
              <span>Professional App ID: <code className="text-neutral-200 font-mono">com.skillloop.pro</code></span>
              <span aria-hidden="true">·</span>
              <span>DPO: <code className="text-neutral-200 font-mono">dpo@skillloop.app</code></span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => {
                if (navigator.clipboard) {
                  navigator.clipboard.writeText(window.location.origin + window.location.pathname);
                  setCopied(true);
                  setTimeout(() => setCopied(false), 2000);
                }
              }}
              className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-xs font-medium transition-colors border border-neutral-700 cursor-pointer flex items-center gap-1"
            >
              {copied ? 'Copied!' : 'Copy Play Store Privacy URL'}
            </button>
          </div>
        </div>

        {/* Quick compliance callout strip */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4 pt-6 border-t border-neutral-100">
          <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-200/70">
            <div className="text-xs font-semibold text-neutral-900 mb-1 flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-neutral-800" />
              <span>Zero Data Sale Guarantee</span>
            </div>
            <p className="text-xs text-neutral-600">
              Personal information is never sold, brokered, or rented to advertisers. Data is scoped strictly to active service bookings.
            </p>
          </div>

          <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-200/70">
            <div className="text-xs font-semibold text-neutral-900 mb-1 flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-neutral-800" />
              <span>18 Standardized Sections</span>
            </div>
            <p className="text-xs text-neutral-600">
              Full coverage of developer identity, customer/pro data boundaries, location, notifications, retention, and rights.
            </p>
          </div>

          <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-200/70 flex flex-col justify-between">
            <div>
              <div className="text-xs font-semibold text-neutral-900 mb-1 flex items-center gap-1.5">
                <Mail className="w-4 h-4 text-neutral-800" />
                <span>Dedicated DPO Contact</span>
              </div>
              <p className="text-xs text-neutral-600">
                Data Protection Officer reachable directly at <span className="font-mono text-neutral-800">dpo@skillloop.app</span> with 48h SLA.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main 2-column layout: Table of contents + content */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Sticky Table of Contents Sidebar */}
        <aside className="lg:col-span-4">
          <div className="sticky top-24 space-y-4">
            <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-neutral-900">Table of Contents</h3>
                <span className="text-xs font-mono text-neutral-500">18 Sections</span>
              </div>

              {/* Search filter input */}
              <div className="relative mb-4">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-neutral-400" />
                <input
                  type="text"
                  placeholder="Filter sections (e.g. location, deletion)..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs bg-neutral-50 border border-neutral-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-neutral-900 text-neutral-800"
                />
              </div>

              <div className="max-h-[60vh] overflow-y-auto space-y-1 pr-1 text-xs">
                {PRIVACY_POLICY_SECTIONS.map((sec) => (
                  <a
                    key={sec.id}
                    href={`#${sec.id}`}
                    className="flex items-center justify-between px-2.5 py-1.5 rounded-md text-neutral-600 hover:text-neutral-950 hover:bg-neutral-100 transition-colors group"
                  >
                    <span className="truncate">
                      <span className="font-mono text-neutral-400 mr-2">{String(sec.number).padStart(2, '0')}.</span>
                      {sec.title}
                    </span>
                    <ChevronRight className="w-3 h-3 text-neutral-300 group-hover:text-neutral-600 shrink-0" />
                  </a>
                ))}
              </div>
            </div>

            {/* Quick Actions Card */}
            <div className="bg-neutral-100 p-4 rounded-xl border border-neutral-200 text-xs space-y-2.5">
              <div className="font-semibold text-neutral-900">Play Store Compliance Links</div>
              <p className="text-neutral-600">
                Direct endpoints required for your Google Play Console store listing submission:
              </p>
              <div className="pt-1 flex flex-col gap-2">
                <button
                  onClick={onNavigateToDeletion}
                  className="w-full text-left px-3 py-2 bg-white rounded-lg border border-neutral-200 font-medium text-neutral-800 hover:bg-neutral-50 transition-colors flex items-center justify-between"
                >
                  <span>Account Deletion URL Flow</span>
                  <span className="font-mono text-[10px] text-neutral-500">Section 11</span>
                </button>
                <button
                  onClick={onNavigateToDataSafety}
                  className="w-full text-left px-3 py-2 bg-white rounded-lg border border-neutral-200 font-medium text-neutral-800 hover:bg-neutral-50 transition-colors flex items-center justify-between"
                >
                  <span>Data Safety Declaration Form</span>
                  <span className="font-mono text-[10px] text-neutral-500">Console Spec</span>
                </button>
              </div>
            </div>
          </div>
        </aside>

        {/* Content column */}
        <main className="lg:col-span-8 space-y-12">
          {filteredSections.length === 0 ? (
            <div className="bg-white p-8 rounded-2xl border border-neutral-200 text-center text-sm text-neutral-500">
              No sections match your search "{searchQuery}". Clear your search query to read the full policy.
            </div>
          ) : (
            filteredSections.map((section) => (
              <section
                key={section.id}
                id={section.id}
                className="scroll-mt-24 bg-white p-6 sm:p-8 rounded-2xl border border-neutral-200/80 shadow-2xs transition-shadow hover:border-neutral-300"
              >
                <div className="flex items-center gap-2 mb-3">
                  <span className="font-mono text-xs font-semibold text-neutral-400">
                    Section {String(section.number).padStart(2, '0')}
                  </span>
                  <span aria-hidden="true" className="text-neutral-300">·</span>
                  <span className="text-xs text-neutral-500">{section.shortSummary}</span>
                </div>

                <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-neutral-900 mb-4">
                  {section.number}. {section.title}
                </h2>

                <div className="space-y-4 text-sm text-neutral-700 leading-relaxed">
                  {section.content.map((paragraph, idx) => (
                    <p key={idx}>{paragraph}</p>
                  ))}
                </div>

                {/* Key Highlights without pills */}
                {section.keyHighlights.length > 0 && (
                  <div className="mt-6 pt-5 border-t border-neutral-100 bg-neutral-50/50 -mx-6 sm:-mx-8 -mb-6 sm:-mb-8 px-6 sm:px-8 py-4 rounded-b-2xl">
                    <div className="text-xs font-semibold uppercase tracking-wider text-neutral-500 mb-2">
                      Key Verification Points
                    </div>
                    <ul className="space-y-1.5 text-xs text-neutral-700">
                      {section.keyHighlights.map((hl, hIdx) => (
                        <li key={hIdx} className="flex items-start gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{hl}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </section>
            ))
          )}
        </main>
      </div>
    </div>
  );
};
