import React from 'react';
import { ShieldCheck, UserX, ExternalLink } from 'lucide-react';

interface HeaderProps {
  activeTab: 'privacy' | 'datasafety' | 'deletion' | 'simulator' | 'security' | 'audit';
  setActiveTab: (tab: 'privacy' | 'datasafety' | 'deletion' | 'simulator' | 'security' | 'audit') => void;
  onOpenDeletionModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenDeletionModal,
}) => {
  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-neutral-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-neutral-900 text-white flex items-center justify-center font-bold text-sm tracking-tighter">
              SL
            </div>
            <button
              onClick={() => setActiveTab('privacy')}
              className="text-lg font-bold tracking-tight text-neutral-900 whitespace-nowrap text-left hover:text-neutral-700 transition-colors"
            >
              SkillLoop <span className="font-normal text-xs text-neutral-500 uppercase tracking-wider ml-1">Legal</span>
            </button>
          </div>

          {/* Zone 2: Concise single-line navigation links */}
          <nav className="hidden md:flex items-center gap-6 text-xs lg:text-sm font-medium text-neutral-600">
            <button
              onClick={() => setActiveTab('privacy')}
              className={`whitespace-nowrap transition-colors py-1 ${
                activeTab === 'privacy'
                  ? 'text-neutral-950 font-semibold border-b-2 border-neutral-900'
                  : 'hover:text-neutral-900'
              }`}
            >
              Privacy Policy (18 Sections)
            </button>

            <button
              onClick={() => setActiveTab('datasafety')}
              className={`whitespace-nowrap transition-colors py-1 ${
                activeTab === 'datasafety'
                  ? 'text-neutral-950 font-semibold border-b-2 border-neutral-900'
                  : 'hover:text-neutral-900'
              }`}
            >
              Data Safety & Permissions
            </button>

            <button
              onClick={() => setActiveTab('deletion')}
              className={`whitespace-nowrap transition-colors py-1 ${
                activeTab === 'deletion'
                  ? 'text-neutral-950 font-semibold border-b-2 border-neutral-900'
                  : 'hover:text-neutral-900'
              }`}
            >
              Account Deletion
            </button>

            <button
              onClick={() => setActiveTab('simulator')}
              className={`whitespace-nowrap transition-colors py-1 ${
                activeTab === 'simulator'
                  ? 'text-neutral-950 font-semibold border-b-2 border-neutral-900'
                  : 'hover:text-neutral-900'
              }`}
            >
              Live Workflow Lab
            </button>

            <button
              onClick={() => setActiveTab('security')}
              className={`whitespace-nowrap transition-colors py-1 ${
                activeTab === 'security'
                  ? 'text-neutral-950 font-semibold border-b-2 border-neutral-900'
                  : 'hover:text-neutral-900'
              }`}
            >
              Attack & Rules Test
            </button>

            <button
              onClick={() => setActiveTab('audit')}
              className={`whitespace-nowrap transition-colors py-1 ${
                activeTab === 'audit'
                  ? 'text-neutral-950 font-semibold border-b-2 border-neutral-900'
                  : 'hover:text-neutral-900'
              }`}
            >
              Audit Report (A–P)
            </button>
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenDeletionModal}
              className="px-3.5 py-2 text-xs font-medium text-white bg-neutral-900 rounded-lg hover:bg-neutral-800 transition-colors whitespace-nowrap flex items-center gap-1.5 shadow-xs"
            >
              <UserX className="w-3.5 h-3.5" />
              <span>Delete Account</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
