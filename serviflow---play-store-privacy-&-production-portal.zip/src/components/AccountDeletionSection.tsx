import React, { useState } from 'react';
import { UserX, ShieldAlert, CheckCircle2, AlertTriangle, ArrowRight, RefreshCw, KeyRound, Clock } from 'lucide-react';
import { UserRole } from '../types';

export const AccountDeletionSection: React.FC = () => {
  const [role, setRole] = useState<UserRole>('CUSTOMER');
  const [email, setEmail] = useState('');
  const [reason, setReason] = useState('NO_LONGER_NEEDED');
  const [notes, setNotes] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedResult, setSubmittedResult] = useState<{
    referenceId: string;
    email: string;
    role: UserRole;
    timestamp: string;
  } | null>(null);

  // Status lookup simulation
  const [lookupId, setLookupId] = useState('');
  const [lookupResult, setLookupResult] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !confirmed) return;

    setIsSubmitting(true);
    setTimeout(() => {
      const refId = `DEL-${Math.floor(100000 + Math.random() * 900000)}`;
      setSubmittedResult({
        referenceId: refId,
        email,
        role,
        timestamp: new Date().toISOString(),
      });
      setIsSubmitting(false);
      setEmail('');
      setNotes('');
      setConfirmed(false);
    }, 600);
  };

  const handleLookup = () => {
    if (!lookupId.trim()) return;
    if (lookupId.toUpperCase().startsWith('DEL-')) {
      setLookupResult(
        `Request ${lookupId.toUpperCase()} is queued. Cryptographic tokens revoked. Profile, phone, and addresses permanently scheduled for purge within 48 hours.`
      );
    } else {
      setLookupResult(`Reference ID ${lookupId} not found. Please verify your deletion reference number.`);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {/* Title & Google Play Context */}
      <div className="border-b border-neutral-200 pb-8">
        <div className="flex items-center gap-2 text-xs text-neutral-500 mb-2">
          <span>Google Play Store Compliance</span>
          <span aria-hidden="true">·</span>
          <span>Data Safety Requirement</span>
          <span aria-hidden="true">·</span>
          <span>Section 11 Implementation</span>
        </div>
        <h1 className="text-3xl font-bold tracking-tight text-neutral-900 mb-3">
          Account & Personal Data Deletion Request Portal
        </h1>
        <p className="text-neutral-600 text-sm max-w-3xl leading-relaxed">
          Google Play Store requires developers to provide a readily accessible public web URL allowing users to request the permanent deletion of their account and associated data. This portal provides immediate, self-serve data deletion requests for both <strong className="text-neutral-900">SkillLoop Customer</strong> and <strong className="text-neutral-900">SkillLoop Pro</strong> users.
        </p>
      </div>

      {/* Policy Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-2xs">
          <div className="flex items-center gap-2 text-sm font-bold text-neutral-900 mb-3">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>What Will Be Permanently Expunged</span>
          </div>
          <ul className="space-y-2 text-xs text-neutral-600 leading-relaxed">
            <li className="flex items-start gap-2">
              <span className="font-mono text-neutral-400">01.</span>
              <span>All authentication credentials, OAuth links, and active session tokens.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="font-mono text-neutral-400">02.</span>
              <span>Profile information, legal names, profile pictures, and contact phone numbers.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="font-mono text-neutral-400">03.</span>
              <span>Physical home addresses, delivery coordinates, and saved location pins.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="font-mono text-neutral-400">04.</span>
              <span>Device push notification tokens (FCM) and marketing communication preferences.</span>
            </li>
          </ul>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-2xs">
          <div className="flex items-center gap-2 text-sm font-bold text-neutral-900 mb-3">
            <ShieldAlert className="w-4 h-4 text-amber-600" />
            <span>Statutory Retention Requirements</span>
          </div>
          <p className="text-xs text-neutral-600 leading-relaxed mb-3">
            In compliance with state, federal, and international tax regulations (such as IRS Code § 6001 and EU VAT directives), financial ledgers and completed job invoices must be retained for seven (7) years.
          </p>
          <div className="bg-amber-50/70 p-3 rounded-lg border border-amber-200/60 text-xs text-amber-900">
            <strong>Retention Boundary:</strong> Retained invoice records are severed from your active identity and stored in restricted, read-only accounting archives accessible solely to statutory auditing authorities.
          </div>
        </div>
      </div>

      {/* Functional Deletion Form */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-neutral-200 shadow-xs">
        <h2 className="text-xl font-bold tracking-tight text-neutral-900 mb-2">
          Submit Deletion Request
        </h2>
        <p className="text-xs text-neutral-500 mb-6">
          Provide your verified email and role to initiate the automated deactivation pipeline.
        </p>

        {submittedResult ? (
          <div className="p-6 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-950 space-y-4">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              <h3 className="text-base font-bold">Deletion Request Successfully Initiated</h3>
            </div>
            <p className="text-xs leading-relaxed">
              Your deletion ticket has been recorded. All active refresh tokens for{' '}
              <strong className="font-mono">{submittedResult.email}</strong> ({submittedResult.role}) have been invalidated immediately.
            </p>
            <div className="bg-white/80 p-3 rounded-lg border border-emerald-200/80 flex items-center justify-between text-xs">
              <span className="text-neutral-600">Confirmation Reference:</span>
              <span className="font-mono font-bold text-neutral-900">{submittedResult.referenceId}</span>
            </div>
            <p className="text-[11px] text-emerald-800">
              A verification link has also been dispatched to your email address. You have a 7-day grace window before permanent database purging commences.
            </p>
            <button
              onClick={() => setSubmittedResult(null)}
              className="text-xs font-medium text-emerald-900 hover:text-emerald-950 underline cursor-pointer"
            >
              Submit another request
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Role selector */}
            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-2">
                Application & Role Type
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setRole('CUSTOMER')}
                  className={`p-3 rounded-xl border text-left text-xs transition-colors ${
                    role === 'CUSTOMER'
                      ? 'bg-neutral-900 text-white border-neutral-900'
                      : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                  }`}
                >
                  <div className="font-bold">Customer App Account</div>
                  <div className={`text-[11px] ${role === 'CUSTOMER' ? 'text-neutral-300' : 'text-neutral-500'}`}>
                    SkillLoop Customer
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setRole('PROFESSIONAL')}
                  className={`p-3 rounded-xl border text-left text-xs transition-colors ${
                    role === 'PROFESSIONAL'
                      ? 'bg-neutral-900 text-white border-neutral-900'
                      : 'bg-neutral-50 text-neutral-700 border-neutral-200 hover:bg-neutral-100'
                  }`}
                >
                  <div className="font-bold">Professional Partner Account</div>
                  <div className={`text-[11px] ${role === 'PROFESSIONAL' ? 'text-neutral-300' : 'text-neutral-500'}`}>
                    SkillLoop Pro (Contractor)
                  </div>
                </button>
              </div>
            </div>

            {/* Email input */}
            <div>
              <label htmlFor="del-email" className="block text-xs font-semibold text-neutral-700 mb-1.5">
                Registered Account Email Address
              </label>
              <input
                id="del-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full px-3.5 py-2 text-sm bg-neutral-50 border border-neutral-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-neutral-900 text-neutral-900"
              />
              <p className="text-[11px] text-neutral-400 mt-1">
                Must match the email address associated with your mobile app account.
              </p>
            </div>

            {/* Reason selector */}
            <div>
              <label htmlFor="del-reason" className="block text-xs font-semibold text-neutral-700 mb-1.5">
                Primary Reason for Deletion (Optional)
              </label>
              <select
                id="del-reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full px-3.5 py-2 text-sm bg-neutral-50 border border-neutral-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-neutral-900 text-neutral-800"
              >
                <option value="NO_LONGER_NEEDED">I no longer require home services</option>
                <option value="PRIVACY_CONCERN">I have privacy or data collection concerns</option>
                <option value="DUPLICATE_ACCOUNT">Duplicate or multiple accounts created</option>
                <option value="SWITCHING_DEVICE">Switching devices or platforms</option>
                <option value="OTHER">Other reason</option>
              </select>
            </div>

            {/* Additional comments */}
            <div>
              <label htmlFor="del-notes" className="block text-xs font-semibold text-neutral-700 mb-1.5">
                Additional Comments or Specific Data Requests (Optional)
              </label>
              <textarea
                id="del-notes"
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Specify any additional instructions for the Data Protection Officer..."
                className="w-full px-3.5 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-neutral-900 text-neutral-900"
              />
            </div>

            {/* Acknowledgment checkbox */}
            <div className="pt-2">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  required
                  checked={confirmed}
                  onChange={(e) => setConfirmed(e.target.checked)}
                  className="mt-0.5 rounded-sm border-neutral-300 text-neutral-900 focus:ring-neutral-900"
                />
                <span className="text-xs text-neutral-600 leading-normal">
                  I understand that this action is irreversible after the 7-day grace window. All active requests will be terminated, and my account credentials will be permanently deactivated in accordance with Section 11 of the Privacy Policy.
                </span>
              </label>
            </div>

            {/* Submit button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting || !confirmed || !email}
                className="w-full sm:w-auto px-6 py-2.5 bg-neutral-900 hover:bg-neutral-800 disabled:bg-neutral-300 text-white font-medium text-xs rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Processing Deletion Request...</span>
                  </>
                ) : (
                  <>
                    <UserX className="w-3.5 h-3.5" />
                    <span>Submit Account Deletion Request</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Status Verification Lookup Section */}
      <div className="bg-neutral-50 p-6 rounded-2xl border border-neutral-200 space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-neutral-900">
          <Clock className="w-4 h-4 text-neutral-600" />
          <span>Track Prior Deletion Request Status</span>
        </div>
        <p className="text-xs text-neutral-600">
          Enter your reference ID (e.g., <span className="font-mono">DEL-849102</span>) to check the current stage of your account purge.
        </p>
        <div className="flex gap-2 max-w-md">
          <input
            type="text"
            placeholder="DEL-XXXXXX"
            value={lookupId}
            onChange={(e) => setLookupId(e.target.value)}
            className="flex-1 px-3 py-1.5 text-xs bg-white border border-neutral-200 rounded-lg font-mono uppercase"
          />
          <button
            type="button"
            onClick={handleLookup}
            className="px-4 py-1.5 bg-neutral-900 text-white rounded-lg text-xs font-medium hover:bg-neutral-800 transition-colors"
          >
            Check Status
          </button>
        </div>

        {lookupResult && (
          <div className="p-3 bg-white rounded-lg border border-neutral-200 text-xs text-neutral-700 mt-2 font-mono">
            {lookupResult}
          </div>
        )}
      </div>
    </div>
  );
};
