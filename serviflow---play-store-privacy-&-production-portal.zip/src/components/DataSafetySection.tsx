import React, { useState } from 'react';
import { PLAY_STORE_DATA_SAFETY_ITEMS, PLAY_STORE_PERMISSIONS_AUDIT } from '../data/dataSafetyData';
import { ShieldCheck, Lock, Download, CheckCircle2, XCircle, AlertCircle, FileText } from 'lucide-react';

export const DataSafetySection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'datasafety' | 'permissions'>('datasafety');

  const handleExportJSON = () => {
    const data = {
      app: 'SkillLoop Customer & SkillLoop Pro',
      exportDate: new Date().toISOString(),
      googlePlayDataSafety: PLAY_STORE_DATA_SAFETY_ITEMS,
      permissionsAudit: PLAY_STORE_PERMISSIONS_AUDIT,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'skillloop-play-store-data-safety-export.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Header */}
      <div className="border-b border-neutral-200 pb-8 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-neutral-500 mb-2">
            <span>Play Console Questionnaire</span>
            <span aria-hidden="true">·</span>
            <span>Policy Sections 13, 14, 17, 20</span>
            <span aria-hidden="true">·</span>
            <span>Production Audit</span>
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-neutral-900 mb-3">
            Google Play Data Safety & Permissions Audit
          </h1>
          <p className="text-neutral-600 text-sm max-w-3xl leading-relaxed">
            Standardized declaration sheet for Google Play Console's Data Safety section and audited AndroidManifest.xml permissions for both the Customer and Professional applications.
          </p>
        </div>

        <button
          onClick={handleExportJSON}
          className="px-4 py-2 bg-neutral-900 text-white text-xs font-medium rounded-lg hover:bg-neutral-800 transition-colors flex items-center gap-2 shrink-0 shadow-2xs"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Play Console JSON</span>
        </button>
      </div>

      {/* Segmented switcher */}
      <div className="flex items-center gap-1 p-1 bg-neutral-100 rounded-xl max-w-md">
        <button
          onClick={() => setActiveTab('datasafety')}
          className={`flex-1 py-2 text-xs font-medium rounded-lg transition-colors ${
            activeTab === 'datasafety'
              ? 'bg-white text-neutral-950 shadow-2xs font-semibold'
              : 'text-neutral-600 hover:text-neutral-900'
          }`}
        >
          Data Safety Questionnaire ({PLAY_STORE_DATA_SAFETY_ITEMS.length} Categories)
        </button>

        <button
          onClick={() => setActiveTab('permissions')}
          className={`flex-1 py-2 text-xs font-medium rounded-lg transition-colors ${
            activeTab === 'permissions'
              ? 'bg-white text-neutral-950 shadow-2xs font-semibold'
              : 'text-neutral-600 hover:text-neutral-900'
          }`}
        >
          AndroidManifest Permissions ({PLAY_STORE_PERMISSIONS_AUDIT.length} Items)
        </button>
      </div>

      {/* TAB 1: DATA SAFETY TABLE */}
      {activeTab === 'datasafety' && (
        <div className="space-y-6">
          {/* Key Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-4 rounded-xl border border-neutral-200">
              <div className="text-xs text-neutral-500 mb-1">Encrypted in Transit</div>
              <div className="text-xl font-bold text-neutral-900 flex items-center gap-1.5">
                <Lock className="w-4 h-4 text-emerald-600" />
                <span>100% of Data Types</span>
              </div>
              <p className="text-[11px] text-neutral-500 mt-1">Enforced by TLS 1.3 and HSTS security</p>
            </div>

            <div className="bg-white p-4 rounded-xl border border-neutral-200">
              <div className="text-xs text-neutral-500 mb-1">Data Deletion Mechanism</div>
              <div className="text-xl font-bold text-neutral-900 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>In-App & Web URL</span>
              </div>
              <p className="text-[11px] text-neutral-500 mt-1">Direct self-serve purge request pipeline</p>
            </div>

            <div className="bg-white p-4 rounded-xl border border-neutral-200">
              <div className="text-xs text-neutral-500 mb-1">Third-Party Data Sale</div>
              <div className="text-xl font-bold text-neutral-900 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Zero Data Sold</span>
              </div>
              <p className="text-[11px] text-neutral-500 mt-1">No ad trackers, data brokers, or marketing resale</p>
            </div>
          </div>

          {/* Full Table */}
          <div className="bg-white rounded-2xl border border-neutral-200 shadow-2xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-neutral-50/80 border-b border-neutral-200 text-neutral-700 font-semibold">
                    <th className="py-3 px-4">Data Category</th>
                    <th className="py-3 px-4">Specific Data Type</th>
                    <th className="py-3 px-4">Collected?</th>
                    <th className="py-3 px-4">Shared?</th>
                    <th className="py-3 px-4">Encrypted?</th>
                    <th className="py-3 px-4">Deletion?</th>
                    <th className="py-3 px-4">Operational Purpose</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {PLAY_STORE_DATA_SAFETY_ITEMS.map((item, idx) => (
                    <tr key={idx} className="hover:bg-neutral-50/50 transition-colors">
                      <td className="py-3 px-4 font-medium text-neutral-900 whitespace-nowrap">
                        {item.category}
                      </td>
                      <td className="py-3 px-4 font-mono text-neutral-800 whitespace-nowrap">
                        {item.dataType}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="text-emerald-700 font-medium">Yes</span>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        {item.shared ? (
                          <span className="text-neutral-800">Yes (Job Party)</span>
                        ) : (
                          <span className="text-neutral-400">No</span>
                        )}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="text-emerald-700 font-medium">Yes (TLS 1.3)</span>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        {item.userCanRequestDeletion ? (
                          <span className="text-emerald-700 font-medium">Eligible</span>
                        ) : (
                          <span className="text-amber-700 font-medium" title="7-year tax audit requirement">
                            7-Yr Tax Audit
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-neutral-600 max-w-xs">
                        {item.purpose}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: PERMISSIONS AUDIT */}
      {activeTab === 'permissions' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-neutral-200 space-y-4">
            <h2 className="text-base font-bold text-neutral-900">
              Google Play Policy Principle: Permission Minimization
            </h2>
            <p className="text-xs text-neutral-600 leading-relaxed">
              Google Play Developer policy strictly forbids requesting sensitive permissions (such as broad storage, contacts, or continuous background location) unless they are core to the application's functional purpose. The table below documents our strict audit of <span className="font-mono text-neutral-800">AndroidManifest.xml</span>:
            </p>

            <div className="overflow-x-auto pt-2">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-neutral-50/80 border-b border-neutral-200 text-neutral-700 font-semibold">
                    <th className="py-3 px-4">Android Permission</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4">App Scope</th>
                    <th className="py-3 px-4">Audit Justification</th>
                    <th className="py-3 px-4">Audit Resolution</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {PLAY_STORE_PERMISSIONS_AUDIT.map((perm, idx) => (
                    <tr key={idx} className="hover:bg-neutral-50/50 transition-colors">
                      <td className="py-3 px-4 font-mono font-medium text-neutral-900 whitespace-nowrap">
                        {perm.permission}
                      </td>
                      <td className="py-3 px-4 text-neutral-600 whitespace-nowrap">
                        {perm.category}
                      </td>
                      <td className="py-3 px-4 text-neutral-800 whitespace-nowrap font-medium">
                        {perm.usedIn}
                      </td>
                      <td className="py-3 px-4 text-neutral-600 max-w-sm">
                        {perm.justification}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        {perm.action.includes('REMOVED') || perm.action.includes('ABSENT') ? (
                          <span className="text-red-700 font-medium">{perm.action}</span>
                        ) : (
                          <span className="text-emerald-700 font-medium">{perm.action}</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
