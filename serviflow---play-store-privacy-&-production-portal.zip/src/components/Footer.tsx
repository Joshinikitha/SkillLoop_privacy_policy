import React from 'react';
import { PRIVACY_POLICY_METADATA } from '../data/privacyPolicyData';
import { ShieldCheck, Mail, MapPin } from 'lucide-react';

interface FooterProps {
  onSelectTab: (tab: 'privacy' | 'datasafety' | 'deletion' | 'simulator' | 'security' | 'audit') => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectTab }) => {
  return (
    <footer className="bg-white border-t border-neutral-200 mt-20 text-neutral-600 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Brand & Purpose */}
          <div className="md:col-span-1 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-neutral-900 text-white flex items-center justify-center font-bold text-xs">
                SL
              </div>
              <span className="font-bold text-sm text-neutral-900">SkillLoop Legal</span>
            </div>
            <p className="text-neutral-500 leading-relaxed text-[11px]">
              Public legal privacy portal and Google Play Store compliance suite for SkillLoop Customer and SkillLoop Pro.
            </p>
            <div className="text-[11px] text-neutral-400">
              Registration: {PRIVACY_POLICY_METADATA.registrationNumber}
            </div>
          </div>

          {/* Policy Links */}
          <div className="space-y-2">
            <div className="font-semibold text-neutral-900 text-xs">Legal & Compliance</div>
            <ul className="space-y-1.5 text-[11px]">
              <li>
                <button
                  onClick={() => onSelectTab('privacy')}
                  className="hover:text-neutral-950 transition-colors text-left"
                >
                  Privacy Policy (18 Sections)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('datasafety')}
                  className="hover:text-neutral-950 transition-colors text-left"
                >
                  Google Play Data Safety Declaration
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('deletion')}
                  className="hover:text-neutral-950 transition-colors text-left"
                >
                  Account & Data Deletion Portal
                </button>
              </li>
              <li>
                <a
                  href="#app-owner-developer"
                  onClick={() => onSelectTab('privacy')}
                  className="hover:text-neutral-950 transition-colors"
                >
                  Terms of Service & Licensing
                </a>
              </li>
            </ul>
          </div>

          {/* Verification Suite */}
          <div className="space-y-2">
            <div className="font-semibold text-neutral-900 text-xs">Production Audit</div>
            <ul className="space-y-1.5 text-[11px]">
              <li>
                <button
                  onClick={() => onSelectTab('simulator')}
                  className="hover:text-neutral-950 transition-colors text-left"
                >
                  Live 6-Step Workflow Simulator
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('security')}
                  className="hover:text-neutral-950 transition-colors text-left"
                >
                  Security Attack Tests (IDOR & RBAC)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('security')}
                  className="hover:text-neutral-950 transition-colors text-left"
                >
                  Production firestore.rules Audit
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('audit')}
                  className="hover:text-neutral-950 transition-colors text-left"
                >
                  Final Play Store Audit Report (A–P)
                </button>
              </li>
            </ul>
          </div>

          {/* DPO & Contact */}
          <div className="space-y-2">
            <div className="font-semibold text-neutral-900 text-xs">Data Protection Officer</div>
            <div className="space-y-1.5 text-[11px] text-neutral-500">
              <div className="flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                <a href="mailto:dpo@serviflow.app" className="text-neutral-800 hover:underline font-mono">
                  dpo@serviflow.app
                </a>
              </div>
              <div className="flex items-start gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0 mt-0.5" />
                <span>San Francisco, CA 94104, USA</span>
              </div>
              <div className="pt-1 text-[10px] text-neutral-400">
                Response SLA: 48 business hours
              </div>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-neutral-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-[11px] text-neutral-500">
          <div>
            © 2026 {PRIVACY_POLICY_METADATA.organization} All rights reserved.
          </div>
          <div className="flex items-center gap-4 text-neutral-400 text-[10px]">
            <span>Google Play Policy v2026.1</span>
            <span aria-hidden="true">·</span>
            <span>GDPR / CCPA Compliant</span>
            <span aria-hidden="true">·</span>
            <span>Last Updated: {PRIVACY_POLICY_METADATA.lastUpdated}</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
