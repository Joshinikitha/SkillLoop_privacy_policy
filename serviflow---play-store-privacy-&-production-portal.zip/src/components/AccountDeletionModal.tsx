import React, { useState } from 'react';
import { X, UserX, CheckCircle2, RefreshCw } from 'lucide-react';
import { UserRole } from '../types';

interface AccountDeletionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AccountDeletionModal: React.FC<AccountDeletionModalProps> = ({ isOpen, onClose }) => {
  const [role, setRole] = useState<UserRole>('CUSTOMER');
  const [email, setEmail] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [ticket, setTicket] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !confirmed) return;
    setIsSubmitting(true);

    setTimeout(() => {
      setTicket(`DEL-${Math.floor(100000 + Math.random() * 900000)}`);
      setIsSubmitting(false);
    }, 500);
  };

  const handleReset = () => {
    setTicket(null);
    setEmail('');
    setConfirmed(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl border border-neutral-200 shadow-xl max-w-lg w-full p-6 text-neutral-900 relative">
        <button
          onClick={handleReset}
          className="absolute right-4 top-4 text-neutral-400 hover:text-neutral-700 p-1"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-2 text-neutral-900 font-bold text-lg">
          <UserX className="w-5 h-5 text-neutral-800" />
          <span>Request Account Deletion</span>
        </div>
        <p className="text-xs text-neutral-500 mb-5">
          Google Play Store Compliance · Permanent Account & Data Purge (Section 11)
        </p>

        {ticket ? (
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-5 text-xs text-emerald-950 space-y-3">
            <div className="flex items-center gap-2 font-bold text-sm text-emerald-900">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Deletion Ticket Queued</span>
            </div>
            <p>
              Your account associated with <strong className="font-mono">{email}</strong> has been deactivated. All active sessions and tokens have been revoked.
            </p>
            <div className="bg-white p-2.5 rounded-lg border border-emerald-200 font-mono text-center font-bold">
              {ticket}
            </div>
            <p className="text-[11px] text-emerald-800">
              Check your inbox for the final confirmation link. Permanent removal occurs after the 7-day grace period.
            </p>
            <button
              onClick={handleReset}
              className="w-full py-2 bg-neutral-900 text-white rounded-lg font-medium text-xs hover:bg-neutral-800 transition-colors mt-2"
            >
              Close
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1.5">Account Role</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setRole('CUSTOMER')}
                  className={`p-2 rounded-lg border text-center transition-colors ${
                    role === 'CUSTOMER'
                      ? 'bg-neutral-900 text-white border-neutral-900 font-medium'
                      : 'bg-neutral-50 border-neutral-200 text-neutral-700 hover:bg-neutral-100'
                  }`}
                >
                  Customer App
                </button>
                <button
                  type="button"
                  onClick={() => setRole('PROFESSIONAL')}
                  className={`p-2 rounded-lg border text-center transition-colors ${
                    role === 'PROFESSIONAL'
                      ? 'bg-neutral-900 text-white border-neutral-900 font-medium'
                      : 'bg-neutral-50 border-neutral-200 text-neutral-700 hover:bg-neutral-100'
                  }`}
                >
                  Professional App
                </button>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                Account Email Address
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="registered@example.com"
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-lg text-neutral-900 text-xs"
              />
            </div>

            <label className="flex items-start gap-2.5 pt-1 cursor-pointer">
              <input
                type="checkbox"
                required
                checked={confirmed}
                onChange={(e) => setConfirmed(e.target.checked)}
                className="mt-0.5 rounded-sm border-neutral-300 text-neutral-900"
              />
              <span className="text-neutral-600 text-[11px] leading-tight">
                I authorize the permanent deletion of my profile, coordinates, and contact details in accordance with Section 11 of the Privacy Policy.
              </span>
            </label>

            <div className="pt-2 flex gap-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 rounded-lg font-medium transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting || !confirmed || !email}
                className="flex-1 py-2 bg-neutral-900 hover:bg-neutral-800 disabled:bg-neutral-300 text-white rounded-lg font-medium transition-colors flex items-center justify-center gap-1.5"
              >
                {isSubmitting ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <UserX className="w-3.5 h-3.5" />
                )}
                <span>Submit Request</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
