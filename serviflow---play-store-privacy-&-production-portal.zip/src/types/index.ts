export type ServiceWorkflowStatus = 
  | 'REQUEST_CREATED'
  | 'PROFESSIONAL_ACCEPTED'
  | 'CUSTOMER_CONFIRMED'
  | 'PROFESSIONAL_ARRIVED'
  | 'JOB_STARTED'
  | 'JOB_COMPLETED'
  | 'CANCELLED';

export type UserRole = 'CUSTOMER' | 'PROFESSIONAL';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone: string;
  verified: boolean;
  avatarUrl?: string;
  rating?: number;
  totalJobs?: number;
}

export interface ServiceRequest {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  serviceCategory: string;
  serviceDescription: string;
  address: string;
  status: ServiceWorkflowStatus;
  createdAt: string;
  updatedAt: string;
  
  // Professional proposal fields (Step 2)
  professionalId?: string;
  professionalName?: string;
  amount?: number;
  scheduledDate?: string;
  scheduledTime?: string;
  
  // Timeline events for audit log
  history: Array<{
    status: ServiceWorkflowStatus;
    timestamp: string;
    actorRole: UserRole;
    note: string;
  }>;
}

export interface AccountDeletionRequest {
  id: string;
  userEmail: string;
  role: UserRole;
  reason: string;
  confirmationCode: string;
  requestedAt: string;
  status: 'SUBMITTED' | 'SCHEDULED_FOR_PURGE' | 'COMPLETED';
}

export interface AuditCheckItem {
  id: string;
  category: string;
  title: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  status: 'PASSED' | 'FIXED' | 'VERIFIED' | 'WARNING';
  description: string;
  remediation: string;
  verifiedInCodebase: boolean;
}

export interface DataSafetyItem {
  category: string;
  dataType: string;
  collected: boolean;
  shared: boolean;
  isOptional: boolean;
  purpose: string;
  ephemeral: boolean;
  encryptedInTransit: boolean;
  userCanRequestDeletion: boolean;
}
