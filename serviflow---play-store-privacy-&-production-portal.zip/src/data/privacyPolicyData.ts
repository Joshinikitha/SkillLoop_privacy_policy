export interface PrivacySection {
  number: number;
  id: string;
  title: string;
  shortSummary: string;
  content: string[];
  keyHighlights: string[];
  subsections?: Array<{ subtitle: string; body: string }>;
}

export const PRIVACY_POLICY_METADATA = {
  lastUpdated: 'October 5, 2026',
  effectiveDate: 'October 5, 2026',
  version: '2026.4-prod-play',
  appNameCustomer: 'SkillLoop – Hire Verified Local Pros & Services',
  appNameProfessional: 'SkillLoop Pro – Service Partner & Job Dispatch',
  organization: 'SkillLoop Technologies, Inc.',
  registrationNumber: 'REG-US-8910472-DE',
  dpoEmail: 'dpo@skillloop.app',
  privacyEmail: 'privacy@skillloop.app',
  supportEmail: 'support@skillloop.app',
  headquarters: '525 Market Street, 28th Floor, San Francisco, CA 94105, United States',
  playStoreConsoleAppIdCustomer: 'com.skillloop.app',
  playStoreConsoleAppIdPro: 'com.skillloop.pro',
};

export const PRIVACY_POLICY_SECTIONS: PrivacySection[] = [
  {
    number: 1,
    id: 'app-owner-developer',
    title: 'App Owner / Developer',
    shortSummary: 'Corporate identity, legal jurisdiction, and designated data controllers for SkillLoop.',
    content: [
      'This Privacy Policy governs the access and usage of the SkillLoop technology platform, comprising the consumer mobile application ("SkillLoop Customer", package ID: com.skillloop.app) and the licensed contractor/vendor application ("SkillLoop Pro", package ID: com.skillloop.pro), alongside all affiliated application programming interfaces (APIs) and web portals (collectively, the "Services").',
      'The designated Data Controller responsible for the processing and protection of personal data collected under this Policy is SkillLoop Technologies, Inc., a Delaware corporation with primary operational headquarters in San Francisco, California, United States.',
      'Whether you access our platform to request on-demand home and facility services ("Customer") or as an independent certified trade contractor or service provider ("Professional"), your personal data is handled with rigorous administrative, technical, and physical safeguards. This policy complies with Google Play Developer Distribution Agreement mandates, the European Union General Data Protection Regulation (Regulation (EU) 2016/679 - GDPR), the California Consumer Privacy Act as amended by the California Privacy Rights Act (Cal. Civ. Code § 1798.100 et seq. - CCPA/CPRA), and applicable international privacy frameworks.'
    ],
    keyHighlights: [
      'Corporate Controller: SkillLoop Technologies, Inc. (Delaware Entity No. REG-US-8910472-DE)',
      'Dual Applications: SkillLoop Customer (com.skillloop.app) & SkillLoop Pro (com.skillloop.pro)',
      'Statutory Frameworks: Google Play Developer Policy, GDPR (EU), CCPA/CPRA (California), COPPA'
    ],
    subsections: [
      {
        subtitle: '1.1 Data Protection Officer (DPO)',
        body: 'SkillLoop has appointed a designated Data Protection Officer to supervise regulatory compliance and handle statutory user inquiries. You may reach our DPO directly at dpo@skillloop.app with a guaranteed acknowledgment window of 48 business hours.'
      },
      {
        subtitle: '1.2 Operational Scope',
        body: 'This policy applies uniformly across all installations of SkillLoop downloaded via the Google Play Store, Android Package installations, and secure progressive web instances.'
      }
    ]
  },
  {
    number: 2,
    id: 'information-we-collect',
    title: 'Information We Collect',
    shortSummary: 'Categories of personal, identity, transaction, location, and device data gathered across our platform.',
    content: [
      'SkillLoop adheres strictly to the fundamental principle of data minimization: we collect only data that is strictly indispensable to facilitate authenticated service matching, contract execution, and secure payment processing between Customers and Professionals.',
      'Information Provided Directly by Customers: Full legal name, verified electronic mail address, primary mobile telephone number, physical service location/address coordinates, service category requisitions, job descriptions, and user authentication credentials (passwords are irreversibly hashed using salted Argon2/bcrypt algorithms with per-user cryptographic salts and never stored in cleartext).',
      'Information Provided by Professionals: Legal entity name, verified government-issued identification credentials (for background screening and anti-fraud verification), certified trade license numbers, tax identification credentials (EIN/SSN tokenized exclusively via PCI-DSS compliant financial providers), service coverage radius, portfolio imagery of completed trade work, and payout banking routing numbers.',
      'Information Gathered Automatically: Internet Protocol (IP) address, Android operating system version, device make and model, unique device installation identifiers (for Firebase Cloud Messaging token routing), network carrier status, and anonymized diagnostic crash telemetry.'
    ],
    keyHighlights: [
      'Customer Identifiers: Legal name, email, mobile phone, verified job address',
      'Professional KYC: Trade license numbers, identity verification tokens, payout routing',
      'Security Invariant: Salted Argon2/bcrypt password hashing; cleartext passwords never exist on disk',
      'Telemetry: Anonymized crash logs and device IDs for FCM push notification delivery'
    ]
  },
  {
    number: 3,
    id: 'how-we-use-information',
    title: 'How We Use Information',
    shortSummary: 'Core purposes: dispatch matching, enforcing the canonical 6-step state machine, and fraud mitigation.',
    content: [
      'Order Facilitation and Matching: Matching Customer service inquiries with licensed, background-checked Professionals operating within the job vicinity, and transmitting the structured service scope for proposal submission.',
      'Enforcing the Canonical 6-Step Service Lifecycle: Facilitating real-time status synchronization across our strictly regulated 6-stage operational state machine: (1) REQUEST_CREATED -> (2) PROFESSIONAL_ACCEPTED (with locked Amount, Date, Time proposal) -> (3) CUSTOMER_CONFIRMED -> (4) PROFESSIONAL_ARRIVED -> (5) JOB_STARTED -> (6) JOB_COMPLETED. Our server architecture blocks any out-of-order stage skipping.',
      'Live Dispatch Tracking & ETA Calculation: Processing foreground geolocation data when a Professional is en route to provide Customers with accurate arrival telemetry and safety assurance.',
      'Platform Security, Identity Verification & Dispute Resolution: Verifying regulatory licensure, calculating algorithmic ratings, enforcing cryptographic role separation (ensuring Customer credentials cannot access Professional features), preventing payment fraud, and generating tax documentation.'
    ],
    keyHighlights: [
      'Server-Authoritative State Machine: Strictly enforces steps 1 through 6',
      'Real-Time Live Sync: Zero-refresh reactive updates between Customer and Pro devices',
      'Role Separation: Enforces strict tenant boundaries between consumers and contractors',
      'Accounting & Audit: Secure generation of transaction receipts and tax records'
    ]
  },
  {
    number: 4,
    id: 'customer-data',
    title: 'Customer Data',
    shortSummary: 'Confidentiality boundaries, scoped field disclosure, and privacy shields for Customer accounts.',
    content: [
      'Shielded Customer Privacy: Exact residential addresses, apartment numbers, and direct customer contact numbers are NEVER exposed to the public marketplace, searchable directories, or unassigned contractors.',
      'Conditional Disclosure Rule: When a Customer posts a request, nearby Professionals observe only the broad neighborhood district and the scope of work. The Customer\'s exact street address and direct phone contact are only revealed to the ONE specific Professional whose proposal has been explicitly accepted by the Customer (transition to CUSTOMER_CONFIRMED).',
      'Immediate Session Teardown: When a service concludes (transition to JOB_COMPLETED or CANCELLED), temporary in-app communication channels are sealed, and active location streaming is immediately terminated.'
    ],
    keyHighlights: [
      'Address Privacy: Precise street addresses remain concealed until Customer confirms proposal',
      'No Public Directory Indexing: Consumer profiles are private and non-searchable',
      'Automatic Session Termination: Contact relay closes immediately upon job completion',
      'Customer Sovereignty: Customers retain exclusive authority to accept or reject contractor bids'
    ]
  },
  {
    number: 5,
    id: 'professional-data',
    title: 'Professional Data',
    shortSummary: 'Licensure verification, binding proposal quotes, and PCI-DSS Level 1 financial protections.',
    content: [
      'Public Professional Credentials: To maintain transparency and marketplace confidence, Customers who receive quotes can inspect the Professional\'s verified first name, business trade rating, verified background check badge, and historical count of completed jobs.',
      'Binding Proposal Integrity: When a Professional accepts an open request, they submit a legally binding proposal specifying Amount ($), Scheduled Date, and Scheduled Time. These parameters are immutable and protected by server-side invariant rules against post-submission manipulation.',
      'Isolated Payout Storage: Payout credentials (such as ACH direct deposit and debit card tokens) are handled exclusively via Level 1 PCI-DSS compliant financial infrastructure. SkillLoop servers never store raw bank account numbers or cardholder PANs.',
      'Background Check Confidentiality: Records of criminal background checks, motor vehicle records, and trade credentials are encrypted in isolated administrative data vaults and are not accessible via standard application queries.'
    ],
    keyHighlights: [
      'Public Badges: Verified trade status, consumer ratings, total completed jobs',
      'Immutable Proposals: Price, date, and time are locked upon submission',
      'Financial Security: PCI-DSS Level 1 tokenized banking payouts',
      'Vaulted KYC Records: Background check files stored in encrypted regulatory vaults'
    ]
  },
  {
    number: 6,
    id: 'communication',
    title: 'Communication',
    shortSummary: 'Lifecycle-driven push notifications, masked telephone relays, and user preferences.',
    content: [
      'Critical Workflow Push Notifications: Real-time mobile alerts are transmitted exclusively to inform parties of mandatory lifecycle events: proposal dispatch, booking confirmation, contractor arrival, job commencement, and completion sign-off.',
      'Masked Telephony and In-App Messaging: Direct telephone contact between Customers and Professionals utilizes virtual masked telephone relays to prevent either party from obtaining personal cellular numbers.',
      'Marketing Restraint: SkillLoop does not conduct third-party marketing telemarketing, unsolicited robocalls, or third-party SMS marketing. Transactional notifications required for service execution cannot be disabled during an active booking, but general marketing digests may be disabled at any time in Account Settings.'
    ],
    keyHighlights: [
      'Workflow Notifications: Sent for all 6 lifecycle stages to coordinate dispatch',
      'Masked Relay: Virtual phone proxies protect private mobile numbers',
      'Anti-Spam Commitment: Zero third-party marketing calls or promotional text broadcasts'
    ]
  },
  {
    number: 7,
    id: 'third-party-services',
    title: 'Third-Party Services',
    shortSummary: 'Enterprise SDK audit, Google Cloud integrations, and vendor privacy contracts.',
    content: [
      'Google Firebase Authentication: Provides identity verification, multi-factor SMS OTP authentication, and cryptographic session token minting under enterprise Google Cloud terms.',
      'Google Cloud Firestore: Scalable cloud database storing structured application documents, governed by strict server-side Firestore Security Rules enforcing role-based access control (RBAC).',
      'Firebase Cloud Messaging (FCM): Facilitates push alerts across Android devices using ephemeral device tokens.',
      'Google Maps Platform (Geocoding & Places SDK): Translates entered service addresses into geographic coordinates and assists en-route turn-by-turn navigation for Professionals.',
      'Firebase Crashlytics: Analyzes anonymized application crash stack traces to ensure mobile stability across diverse Android device configurations.',
      'All third-party subprocessors are bound by rigorous Data Processing Addendums (DPAs) mandating adherence to GDPR Article 28 and CCPA requirements.'
    ],
    keyHighlights: [
      'Firebase Auth & Firestore: Encrypted storage, JWT authentication, and strict RBAC',
      'FCM & Crashlytics: Certified delivery and anonymized crash analytics',
      'Google Maps Platform: Scoped navigation and location decoding without persistent tracking',
      'Subprocessor DPAs: Legally binding GDPR Article 28 data protection addendums'
    ]
  },
  {
    number: 8,
    id: 'data-sharing',
    title: 'Data Sharing',
    shortSummary: 'Strict non-sale commitment; operational data disclosure restricted to active service engagements.',
    content: [
      'SKILLLOOP DOES NOT SELL, RENT, OR MONETIZE PERSONAL DATA. We have never sold user data to data brokers, ad networks, or commercial resellers, and we will never do so.',
      'Operational Inter-Party Disclosure: Personal data is disclosed solely between the Customer and the assigned Professional to the exact degree required to perform the agreed service engagement.',
      'Compelled Legal Disclosures: We may disclose user data if required by valid court subpoenas, judicial warrants, or statutory enforcement orders, or where necessary to prevent imminent physical bodily harm.',
      'Corporate Reorganization: In the event of a merger, acquisition, or restructuring, personal data will remain governed by this Privacy Policy unless modified with affirmative prior notice.'
    ],
    keyHighlights: [
      'Zero Data Sale Guarantee: Explicit prohibition against selling personal records',
      'Confined Disclosures: Information shared strictly between Customer and confirmed Professional',
      'Judicial Scrutiny: Subpoena disclosures evaluated for strict constitutional validity'
    ]
  },
  {
    number: 9,
    id: 'data-security',
    title: 'Data Security',
    shortSummary: 'Defense-in-depth: TLS 1.3 encryption, AES-256 storage, strict RBAC, and IDOR prevention.',
    content: [
      'Cryptographic Encryption Standards: All data in transit across public networks is encrypted utilizing Transport Layer Security (TLS 1.3) with HTTP Strict Transport Security (HSTS). All database volumes, backups, and user records are encrypted at rest using Advanced Encryption Standard (AES-256).',
      'Role-Based Access Control (RBAC): The application backend validates authenticated claims on every transaction. Customer tokens invoking Professional management APIs are rejected with HTTP 403 Forbidden.',
      'IDOR Protection: Insecure Direct Object Reference attacks are eliminated. Backend routes enforce strict ownership matching: request.auth.uid must equal resource.customerId or resource.professionalId.',
      'Server-Authoritative State Enforcement: Status transitions are guarded by deterministic server-side state machines. Out-of-order transitions are rejected with HTTP 400 Bad Request.'
    ],
    keyHighlights: [
      'In-Transit: TLS 1.3 encryption with strict HSTS certificate pinning',
      'At-Rest: AES-256 encryption across all Firestore partitions',
      'Access Control: Comprehensive RBAC and IDOR ownership verification',
      'State Guard: Server-enforced state machine blocking out-of-order transitions'
    ]
  },
  {
    number: 10,
    id: 'data-retention',
    title: 'Data Retention',
    shortSummary: 'Clear retention schedules: tax accounting records, active accounts, and 24h GPS purging.',
    content: [
      'Active User Records: Profile information and active service orders remain active for the duration of the user\'s account tenure.',
      'Ephemeral Geolocation Telemetry: Real-time GPS coordinates transmitted during contractor transit are buffered in memory and permanently expunged within 24 hours of job completion.',
      'Commercial Financial Invoices: In compliance with statutory taxation laws (IRS Code § 6001, state sales tax codes, and commercial accounting regulations), finalized service invoices, transaction amounts, and payment receipts are retained in an immutable, access-restricted archive for seven (7) years.',
      'Inactive Accounts: Accounts dormant for 24 continuous months undergo automated archival notification and scheduled deactivation.'
    ],
    keyHighlights: [
      'Active Data: Maintained during the lifecycle of the user account',
      'Ephemeral GPS: Purged within 24 hours following service completion',
      'Statutory Records: Invoices and transaction logs retained for 7 years for tax audits',
      'Dormant Accounts: 24-month inactivity review and archival'
    ]
  },
  {
    number: 11,
    id: 'account-deletion',
    title: 'Account Deletion',
    shortSummary: 'Direct self-serve web URL and in-app account deletion flow fulfilling Google Play Data Safety rules.',
    content: [
      'Universal Deletion Right: In accordance with Google Play Store User Data policies, users retain the absolute right to delete their account and all associated personal records at any time without punitive conditions.',
      'Self-Serve Access Channels: Users can trigger deletion directly within either mobile app under Account Settings -> Security -> Delete My Account, or via our public web portal on this page under the "Account Deletion" tab.',
      'Automated Deactivation Pipeline: Upon submission, all authentication tokens, refresh tokens, and active sessions are revoked instantly. User profile images, legal names, phone numbers, and address pins are permanently scheduled for purge.',
      'Retention Boundary Disclosures: Completed financial transaction records and tax invoice logs are retained in anonymized, read-only accounting archives for the required 7-year statutory period before final destruction.'
    ],
    keyHighlights: [
      'Direct Public Web URL: Immediate self-serve request submission without mandatory app install',
      'In-App Setting: One-tap deletion flow in both Customer and Pro apps',
      'Token Revocation: Immediate invalidation of all JWT session keys',
      'Clear Exception Notice: Transparent disclosure of statutory tax retention rules'
    ]
  },
  {
    number: 12,
    id: 'childrens-privacy',
    title: 'Children\'s Privacy',
    shortSummary: 'Age restriction (18+), COPPA compliance, and immediate termination of underage accounts.',
    content: [
      'Strict Age Requirement: The SkillLoop platform is exclusively designed and authorized for adults aged eighteen (18) years or older (or the age of legal majority in their home jurisdiction).',
      'Compliance with COPPA & GDPR Art. 8: SkillLoop does not knowingly collect, solicit, or maintain personal information from children under 13 (or under 16 in the European Economic Area).',
      'Underage Account Remediation: If we discover that an account has been registered by an underage minor, our security systems will immediately terminate the account, revoke all session credentials, and permanently purge the data.'
    ],
    keyHighlights: [
      'Strict 18+ policy for all platform participants',
      'Full COPPA and GDPR Article 8 compliance',
      'Zero intentional processing or storage of children\'s data'
    ]
  },
  {
    number: 13,
    id: 'location-data',
    title: 'Location Data',
    shortSummary: 'Precise vs coarse location usage, foreground constraints, and dispatch boundaries.',
    content: [
      'Customer Location Usage: Customers supply their physical street address to indicate where the requested service is to be rendered. SkillLoop does not monitor or track Customer background GPS coordinates.',
      'Professional Foreground Navigation: The SkillLoop Pro application requests ACCESS_FINE_LOCATION and ACCESS_COARSE_LOCATION solely to calculate en-route travel distance and provide live arrival tracking to the waiting Customer.',
      'Strict Foreground-Only Boundary: Location tracking executes exclusively while the Professional is actively navigating toward an accepted booking (between CUSTOMER_CONFIRMED and PROFESSIONAL_ARRIVED). SkillLoop does not monitor contractor locations during off-duty hours or between jobs.'
    ],
    keyHighlights: [
      'Customer Location: Single static job location; zero background tracking',
      'Professional Location: Foreground GPS broadcast active only while en route',
      'No 24/7 Surveillance: Off-duty location tracking is strictly prohibited by software architecture'
    ]
  },
  {
    number: 14,
    id: 'notifications',
    title: 'Notifications',
    shortSummary: 'Push notification runtime permissions (POST_NOTIFICATIONS) and notification categories.',
    content: [
      'Android 13+ Runtime Permissions: In accordance with Android 13 (API Level 33+) requirements, SkillLoop explicitly requests the POST_NOTIFICATIONS runtime permission before delivering push notifications.',
      'Categorized Notification Channels: Alerts are organized into explicit notification channels: (1) Service Workflow Updates (e.g., proposal received, contractor arrived, job completed), (2) Security Alerts (e.g., password reset, new device login), and (3) Informational Account Summaries.',
      'Notification Controls: Users can customize or silence notification channels at any time via Android System Settings -> Apps -> SkillLoop -> Notifications without degrading core booking functionality.'
    ],
    keyHighlights: [
      'Explicit POST_NOTIFICATIONS runtime authorization on Android 13+',
      'Fine-grained notification channels for dispatch, security, and updates',
      'Freedom to silence non-critical notifications in device settings'
    ]
  },
  {
    number: 15,
    id: 'cookies-tracking',
    title: 'Cookies / Tracking',
    shortSummary: 'Token-based session management, zero third-party advertising cookies, and tracking policies.',
    content: [
      'Native Mobile Applications: The SkillLoop Customer and SkillLoop Pro native Android applications do not use web cookies. Authentication sessions are governed by cryptographically signed JWT access tokens stored securely in Android Keystore-backed encrypted storage.',
      'Web Legal Portal: This legal and compliance portal uses only strictly necessary functional session storage to preserve navigation state and accessibility preferences. We do not deploy third-party advertising tracking cookies, behavioral tracking pixels, or cross-app tracking SDKs.'
    ],
    keyHighlights: [
      'Zero third-party advertising cookies or cross-app tracking pixels',
      'Android Keystore-backed secure token storage on mobile devices',
      'Web portal utilizes strictly functional local storage'
    ]
  },
  {
    number: 16,
    id: 'user-rights',
    title: 'User Rights',
    shortSummary: 'Comprehensive global data rights: access, rectification, portability, and erasure under GDPR & CCPA.',
    content: [
      'Regardless of your country of residence, SkillLoop guarantees the following comprehensive data subject rights:',
      'Right of Access & Portability: You may request a complete, machine-readable export (JSON format) of your personal profile and historical service records.',
      'Right to Rectification: You may update or correct inaccurate profile details directly within the mobile application or by notifying support.',
      'Right to Erasure ("Right to Be Forgotten"): You may request the permanent deletion of your account and personal data via our Account Deletion portal.',
      'Right to Restrict or Object to Processing: You may object to non-essential processing activities, including marketing communications.',
      'Non-Discrimination Guarantee: SkillLoop will never deny services, charge discriminatory prices, or alter service quality because you exercised your statutory privacy rights.'
    ],
    keyHighlights: [
      'Comprehensive GDPR (Articles 15–22) and CCPA/CPRA rights',
      'Machine-readable data portability in structured JSON format',
      'Absolute non-discrimination guarantee for exercising rights'
    ]
  },
  {
    number: 17,
    id: 'changes-to-policy',
    title: 'Changes to Policy',
    shortSummary: 'Revision schedules, version tracking, and advance notification procedures for policy modifications.',
    content: [
      'Periodic Legal Review: SkillLoop conducts regular audits of this Privacy Policy to ensure alignment with technological updates, cloud infrastructure enhancements, and emerging international regulations.',
      'Advance Notice of Material Updates: When material modifications are made, we will notify users at least thirty (30) days in advance through prominent in-app notification banners and electronic mail to your registered address.',
      'Version Archival: The "Last Updated" timestamp at the top of this document indicates the effective release date. Historical versions of this policy are permanently cataloged and available upon request.'
    ],
    keyHighlights: [
      '30-day advance notice for material policy modifications',
      'Direct in-app notification and electronic mail announcements',
      'Transparent version history cataloged for public inspection'
    ]
  },
  {
    number: 18,
    id: 'contact-us',
    title: 'Contact Us',
    shortSummary: 'Direct communication channels for the Data Protection Officer and corporate legal team.',
    content: [
      'If you have questions, feedback, or statutory data requests regarding this Privacy Policy or our operational data practices, please contact our legal and privacy team:',
      'Corporate Entity: SkillLoop Technologies, Inc.',
      'Attention: Data Protection Officer / Legal & Privacy Compliance Office',
      'Electronic Mail: dpo@skillloop.app (General Privacy Inquiries: privacy@skillloop.app)',
      'Postal Address: 525 Market Street, 28th Floor, San Francisco, CA 94105, United States',
      'Telephone Support: +1 (888) 545-5667 (Mon–Fri, 9:00 AM – 5:00 PM PST)',
      'Response SLA: We acknowledge all formal inquiries within 48 business hours and resolve comprehensive statutory rights requests within thirty (30) calendar days.'
    ],
    keyHighlights: [
      'Direct DPO Email: dpo@skillloop.app',
      'Corporate Headquarters: 525 Market Street, 28th Floor, San Francisco, CA 94105',
      'Guaranteed 48-hour inquiry acknowledgment SLA'
    ]
  }
];

export const SKILLLOOP_TERMS_SECTIONS = [
  {
    id: 'terms-scope',
    title: '1. Service Agreement & Marketplace Relationship',
    content: [
      'SkillLoop provides a software technology platform connecting independent consumers ("Customers") with licensed, independent trade service providers ("Professionals"). SkillLoop is a technology intermediary and does not directly provide plumbing, electrical, or construction labor.',
      'Contractors are independent third-party business operators and are not employees, agents, or joint venturers of SkillLoop Technologies, Inc.'
    ]
  },
  {
    id: 'terms-proposals',
    title: '2. Proposals & Binding Quotes',
    content: [
      'When a Professional submits a proposal on SkillLoop, the specified Amount, Date, and Time constitute a binding offer. Once confirmed by the Customer (CUSTOMER_CONFIRMED), the quote cannot be modified without mutual in-app consent.',
      'Customers are under no obligation to accept any submitted proposal and may reject proposals without penalty.'
    ]
  },
  {
    id: 'terms-completion',
    title: '3. Job Sign-off & Payment Settlement',
    content: [
      'SkillLoop enforces customer-authorized completion: only the Customer can inspect completed work and submit final sign-off (JOB_COMPLETED).',
      'Payment settlement occurs following Customer completion sign-off via tokenized payment processing.'
    ]
  },
  {
    id: 'terms-liability',
    title: '4. Limitation of Liability',
    content: [
      'To the maximum extent permitted by applicable law, SkillLoop Technologies, Inc. shall not be liable for indirect, incidental, or consequential damages resulting from trade services performed by independent Professionals.'
    ]
  }
];
