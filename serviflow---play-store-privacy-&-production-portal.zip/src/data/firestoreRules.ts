export const PRODUCTION_FIRESTORE_RULES = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // Helper functions for security validation
    function isAuthenticated() {
      return request.auth != null;
    }

    function isUser(userId) {
      return isAuthenticated() && request.auth.uid == userId;
    }

    function getUserData() {
      return get(/databases/$(database)/documents/users/$(request.auth.uid)).data;
    }

    function isCustomer() {
      return isAuthenticated() && (
        request.auth.token.role == 'CUSTOMER' || 
        getUserData().role == 'CUSTOMER'
      );
    }

    function isProfessional() {
      return isAuthenticated() && (
        request.auth.token.role == 'PROFESSIONAL' || 
        getUserData().role == 'PROFESSIONAL'
      );
    }

    // 1. User Profiles Collection
    match /users/{userId} {
      // Any authenticated user can read minimal profile data of an assigned counterpart
      allow read: if isAuthenticated();
      
      // User can create their own profile upon registration
      allow create: if isUser(userId) 
        && request.resource.data.role in ['CUSTOMER', 'PROFESSIONAL']
        && request.resource.data.email == request.auth.token.email;

      // User can update their own profile, BUT CANNOT change their role or verification status
      allow update: if isUser(userId)
        && request.resource.data.role == resource.data.role
        && (!request.resource.data.diff(resource.data).affectedKeys().hasAny(['role', 'verified', 'id']));

      // Deletion allowed only via authenticated account deletion pipeline
      allow delete: if isUser(userId);
    }

    // 2. Service Requests Collection (Strict Workflow Enforcement)
    match /service_requests/{requestId} {
      
      // READ: Customer owner can read. Professional can read if unassigned (in discovery) 
      // or if assigned to this request.
      allow read: if isAuthenticated() && (
        resource.data.customerId == request.auth.uid ||
        (isProfessional() && (resource.data.status == 'REQUEST_CREATED' || resource.data.professionalId == request.auth.uid))
      );

      // CREATE: Strictly CUSTOMER can create a request with status 'REQUEST_CREATED'
      allow create: if isCustomer() 
        && request.resource.data.customerId == request.auth.uid
        && request.resource.data.status == 'REQUEST_CREATED'
        && request.resource.data.createdAt != null;

      // UPDATE: Governed by exact business state machine
      allow update: if isAuthenticated() && (
        
        // TRANSITION 1: Professional Accepts & Submits Proposal
        // REQUEST_CREATED -> PROFESSIONAL_ACCEPTED
        (
          isProfessional() &&
          resource.data.status == 'REQUEST_CREATED' &&
          request.resource.data.status == 'PROFESSIONAL_ACCEPTED' &&
          request.resource.data.professionalId == request.auth.uid &&
          request.resource.data.amount is number &&
          request.resource.data.amount > 0 &&
          request.resource.data.scheduledDate is string &&
          request.resource.data.scheduledTime is string &&
          request.resource.data.customerId == resource.data.customerId
        ) ||

        // TRANSITION 2A: Customer Confirms Proposal
        // PROFESSIONAL_ACCEPTED -> CUSTOMER_CONFIRMED
        (
          isCustomer() &&
          resource.data.customerId == request.auth.uid &&
          resource.data.status == 'PROFESSIONAL_ACCEPTED' &&
          request.resource.data.status == 'CUSTOMER_CONFIRMED' &&
          // Customer CANNOT alter the professional's proposed amount or time
          request.resource.data.amount == resource.data.amount &&
          request.resource.data.scheduledDate == resource.data.scheduledDate &&
          request.resource.data.scheduledTime == resource.data.scheduledTime &&
          request.resource.data.professionalId == resource.data.professionalId
        ) ||

        // TRANSITION 2B: Customer Rejects Proposal
        // PROFESSIONAL_ACCEPTED -> CANCELLED
        (
          isCustomer() &&
          resource.data.customerId == request.auth.uid &&
          resource.data.status == 'PROFESSIONAL_ACCEPTED' &&
          request.resource.data.status == 'CANCELLED'
        ) ||

        // TRANSITION 3: Professional Marks Arrived
        // CUSTOMER_CONFIRMED -> PROFESSIONAL_ARRIVED
        (
          isProfessional() &&
          resource.data.professionalId == request.auth.uid &&
          resource.data.status == 'CUSTOMER_CONFIRMED' &&
          request.resource.data.status == 'PROFESSIONAL_ARRIVED'
        ) ||

        // TRANSITION 4: Professional Starts Job
        // PROFESSIONAL_ARRIVED -> JOB_STARTED
        (
          isProfessional() &&
          resource.data.professionalId == request.auth.uid &&
          resource.data.status == 'PROFESSIONAL_ARRIVED' &&
          request.resource.data.status == 'JOB_STARTED'
        ) ||

        // TRANSITION 5: Customer Completes Job
        // JOB_STARTED -> JOB_COMPLETED
        // (NOTE: Strict security rule enforces ONLY customer can mark job completed!)
        (
          isCustomer() &&
          resource.data.customerId == request.auth.uid &&
          resource.data.status == 'JOB_STARTED' &&
          request.resource.data.status == 'JOB_COMPLETED'
        )
      );

      // DELETE: Not allowed directly to maintain auditable ledger
      allow delete: if false;
    }

    // 3. Account Deletion Requests Collection
    match /deletion_requests/{requestId} {
      allow create: if isAuthenticated() && request.resource.data.userId == request.auth.uid;
      allow read: if isAuthenticated() && (resource.data.userId == request.auth.uid);
      allow update, delete: if false; // Processed server-side via Cloud Function
    }
  }
}`;

export const ANDROID_MANIFEST_AUDIT_XML = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.skillloop.app">

    <!-- Essential Network Permissions -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <!-- Push Notifications (API 33+) -->
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <!-- Location Permissions: Scoped to en-route job navigation -->
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />

    <!-- Camera: Optional KYC ID Verification (Feature Not Required) -->
    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-permission android:name="android.permission.CAMERA" />

    <!-- SECURITY AUDIT: REMOVED DANGEROUS UNNECESSARY PERMISSIONS -->
    <!-- [REMOVED] android.permission.READ_EXTERNAL_STORAGE -->
    <!-- [REMOVED] android.permission.WRITE_EXTERNAL_STORAGE -->
    <!-- [REMOVED] android.permission.READ_CONTACTS -->
    <!-- [REMOVED] android.permission.RECORD_AUDIO -->
    <!-- [REMOVED] android.permission.ACCESS_BACKGROUND_LOCATION -->

    <application
        android:allowBackup="false"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.SkillLoop"
        android:networkSecurityConfig="@xml/network_security_config">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:screenOrientation="portrait">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Disable debuggable in release build (checked via build.gradle) -->
    </application>
</manifest>`;
